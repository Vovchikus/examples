define([
    './dashboard-news',
    './dashboard-profile',
    './dashboard-vacancies',
    './login',
    './main',
    './notifications',
    './registration'
], function () {});
