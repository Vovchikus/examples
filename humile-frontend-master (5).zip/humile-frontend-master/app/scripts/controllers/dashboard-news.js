define([
    'app'
], function (app) {
    'use strict';

    /**
     * @param NewsResource
     * @constructor
     */
    function DashboardNewsController(NewsResource) {
        function init() {
            NewsResource.list({
                filter: {'isActual': true},
                fields: 'id,title,content,created'
            }, function (news) {
                vm.items = news;
            });
        }

        // DashboardNewsController
        // -----------------------------------
        var vm = this;

        vm.init = init;
        vm.items = [];

        vm.init();
    }

    DashboardNewsController.$inject = ['NewsResource'];

    app.controller('DashboardNewsController', DashboardNewsController);
});
