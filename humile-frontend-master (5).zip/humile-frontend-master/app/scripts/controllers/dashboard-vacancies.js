define([
    'app'
], function (app) {
    'use strict';

    /**
     * @param VacancyResource
     * @constructor
     */
    function DashboardVacancyController(VacancyResource) {
        /**
         * Initialization
         */
        function init() {
            VacancyResource.list(
                {
                    'filter':  {'status': 'published'},
                    'fields':  'id,status,title,stats',
                    'orderBy': 'status'
                },
                function (items) {
                    vm.items = items;
                    vm.isLoaded = true;
                }
            );
        }

        // DashboardVacancyController
        // -----------------------------------
        var vm = this;

        vm.init = init;
        vm.items = [];
        vm.isLoaded = false;

        vm.init();
    }

    DashboardVacancyController.$inject = ['VacancyResource'];

    app.controller('DashboardVacancyController', DashboardVacancyController);
});
