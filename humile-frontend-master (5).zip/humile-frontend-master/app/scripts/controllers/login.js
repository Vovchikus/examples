define([
    'app',
    'underscore',
    'services/auth'
], function (app, _) {
    'use strict';

    app.controller('LoginFormController', [
        '$scope', '$http', '$state', 'Auth', 'UserResource',
        function ($scope, $http, $state, Auth, UserResource) {
            $scope.account = {};
            $scope.authMsg = '';

            $scope.login = function () {
                UserResource.authorize($scope.account, function (data) {
                    Auth.login(data);
                    UserResource.info({}, function (data) {
                        Auth.setData(data);
                        $state.go('app.dashboard');
                    });
                }, function () {
                    $scope.authMsg = 'Ошибка авторизации';
                });
            };
        }]);
});
