define([
    'app'
], function (app) {
    'use strict';

    /**
     * @param NotificationResource
     * @param NotificationService
     * @constructor
     */
    function NotificationController(NotificationResource, NotificationService) {
        /**
         * Initialization
         */
        function init() {
            NotificationResource.list({},
                function (items, getHeaders) {
                    NotificationService.setCount(getHeaders('x-count'), getHeaders('x-count-new'));
                    vm.items = items;
                    vm.isLoaded = true;
                }
            );
        }

        // NotificationController
        // -----------------------------------
        var vm = this;

        vm.init = init;
        vm.go = NotificationService.go;
        vm.count = NotificationService.getCount;
        vm.items = [];
        vm.isLoaded = false;

        vm.init();
    }

    /**
     * @param NotificationResource
     * @param NotificationService
     * @param Table
     * @constructor
     */
    function NotificationListController(NotificationResource, NotificationService, Table) {
        /**
         *
         * @param item
         */
        function go(item) {
            NotificationService.go(item);
        }

        // NotificationListController
        // -----------------------------------
        var vm = this;

        vm.go = go;
        vm.items = [];
        vm.isLoaded = false;

        vm.table = Table;
        vm.table.init(NotificationResource.list);
    }

    /**
     *
     * @param $rootScope
     * @param NotificationResource
     * @returns {{setCount: Function, getCount: {all: Function, onlyNew: Function}, go: Function}}
     * @constructor
     */
    function NotificationService($rootScope, NotificationResource) {
        var count = {
            all:     0,
            onlyNew: 0
        };

        return {
            setCount: function (all, onlyNew) {
                count.all = all;
                count.onlyNew = onlyNew;
            },
            getCount: {
                all:     function () {
                    return count.all;
                },
                onlyNew: function () {
                    return count.onlyNew;
                }
            },
            go:       function (item) {
                if (item.status === 'new') {
                    NotificationResource.setViewed({id: item.id});
                    item.status = 'viewed';
                    count.onlyNew--;
                }

                if (item.type === 'vacancy') {
                    $rootScope.$state.go('app.vacancy', {id: item.data.vacancy.id});
                }
            }
        };
    }

    NotificationService.$inject = ['$rootScope', 'NotificationResource'];
    app.factory('NotificationService', NotificationService);

    NotificationController.$inject = ['NotificationResource', 'NotificationService'];
    NotificationListController.$inject = ['NotificationResource', 'NotificationService', 'DataTable'];

    app.controller('NotificationController', NotificationController);
    app.controller('NotificationListController', NotificationListController);
});
