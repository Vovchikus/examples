define([
    'app',
    'underscore',
    'services/auth'
], function (app, _) {
    'use strict';

    // @todo HELLHERE
    app.controller('AppController',
        ['$rootScope', '$scope', '$state', '$window', '$localStorage', '$timeout', 'toggleStateService', 'browser', 'cfpLoadingBar', 'Auth', 'Api', 'ngDialog',
            function ($rootScope, $scope, $state, $window, $localStorage, $timeout, toggle, browser, cfpLoadingBar, Auth, Api, ngDialog) {
                // Loading bar transition
                // -----------------------------------
                var thBar;
                $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                    if ($('.wrapper > section').length) // check if bar container exists
                        thBar = $timeout(function () {
                            cfpLoadingBar.start();
                        }, 0); // sets a latency Threshold
                });
                $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                    event.targetScope.$watch('$viewContentLoaded', function () {
                        $timeout.cancel(thBar);
                        cfpLoadingBar.complete();
                    });
                });

                // Hook success
                $rootScope.$on('$stateChangeSuccess',
                    function (event, toState, toParams, fromState, fromParams) {
                        $window.scrollTo(0, 0);
                        $rootScope.currTitle = $state.current.title;
                    });

                $rootScope.currTitle = $state.current.title;
                $rootScope.pageTitle = function () {
                    return $rootScope.app.name + ' - ' + ($rootScope.currTitle || $rootScope.app.description);
                };

                $rootScope.$watch('app.isCollapsed', function (newValue, oldValue) {
                    if (newValue === false)
                        $rootScope.$broadcast('closeSidebarMenu');
                });

                // Restore application classes state
                toggle.restoreState($(document.body));

                // Applies animation to main view for the next pages to load
                $timeout(function () {
                    $rootScope.mainViewAnimation = $rootScope.app.viewAnimation;
                });

                // cancel click event easily
                $rootScope.cancel = function ($event) {
                    $event.stopPropagation();
                };

                // Local storage defaults
                // -----------------------------------
                $rootScope.storage = $localStorage.$default({
                    user: {},
                    cache: {
                        'default-email': ''
                    }
                });
                $rootScope.cache = $rootScope.storage.cache;


                // Authorization
                // -----------------------------------
                $scope.user = Auth;

                if (!$scope.user.isAuthorized()) {
                    $scope.user.logout();
                }

                $scope.staticURL = Api.api.statics;

                /**
                 * Usage example:
                 * $rootScope.checkAccess('admin');
                 * $rootScope.checkAccess(['admin', 'hr]);
                 *
                 * @param role Role/roles list
                 */
                $rootScope.checkAccess = function (role) {
                    if (!_.isArray(role)) {
                        role = [role];
                    }

                    if (!Auth.roleIn(role)) {
                        $rootScope.$state.go('page.403');
                    }
                };

                $rootScope.getDialog = function (scope, template, options) {
                    scope = _.extend($scope.$new(), scope);

                    if (_.isUndefined(options)) {
                        options = {};
                    }

                    return ngDialog.openConfirm({
                        template:         template,
                        preCloseCallback: 'preCloseCallbackOnScope',
                        className:        options.className || 'ngdialog-theme-default',
                        closeByDocument:  true,
                        closeByEscape:    true,
                        scope:            scope
                    });
                };
                
                $scope.search = function (query) {
                    $state.go('app.search', {query: query});
                };
            }])
        .controller('SidebarController', ['$rootScope', '$scope', '$state', '$location', '$http', '$timeout', 'MEDIAQUERY', 'UserResource',
            function ($rootScope, $scope, $state, $location, $http, $timeout, mediaQuery, UserResource) {

                var currentState = $rootScope.$state.current.name;
                var $win = $(window);
                var $html = $('html');
                var $body = $('body');

                // Adjustment on route changes
                $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                    currentState = toState.name;
                    $('body.aside-toggled').removeClass('aside-toggled');

                    $rootScope.$broadcast('closeSidebarMenu');
                });

                $win.on('resize', function () {
                    if (isMobile())
                        $body.removeClass('aside-collapsed');
                    else
                        $body.removeClass('aside-toggled');
                });

                var isActive = function (item) {
                    if (!item) return;
                    if (!item.sref || item.sref == '#') {
                        var foundActive = false;
                        angular.forEach(item.submenu, function (value, key) {
                            if (isActive(value)) foundActive = true;
                        });
                        return foundActive;
                    }
                    else
                        return $state.is(item.sref) || $state.includes(item.sref);
                };

                // Load menu from json file
                // -----------------------------------
                $scope.getMenuItemPropClasses = function (item) {
                    return (item.heading ? 'nav-heading' : '') +
                        (isActive(item) ? ' active' : '');
                };

                $rootScope.menuItems = {};
                $scope.loadSidebarMenu = function () {
                    $rootScope.menuItems = UserResource.loadMenu();
                };

                $rootScope.$on('menuChanged', function(event, changedItems) {
                    if (_.isArray(changedItems)) {
                        UserResource.loadMenu(function(menu) {
                            _.forEach(changedItems, function(item){
                                $rootScope.menuItems[item] = menu[item];
                            })
                        });

                    }
                });

                $scope.loadSidebarMenu();

                // Handle sidebar collapse items
                // -----------------------------------
                var collapseList = [];

                $scope.addCollapse = function ($index, item) {
                    collapseList[$index] = !isActive(item);
                };

                $scope.isCollapse = function ($index) {
                    return (collapseList[$index]);
                };

                $scope.toggleCollapse = function ($index, isParentItem) {
                    if (isSidebarCollapsed() && !isMobile()) return true;
                    if (angular.isDefined(collapseList[$index])) {
                        collapseList[$index] = !collapseList[$index];
                        closeAllBut($index);
                    }
                    else if (isParentItem) {
                        closeAllBut(-1);
                    }

                    return true;

                    function closeAllBut(index) {
                        index += '';
                        for (var i in collapseList) {
                            if (index < 0 || index.indexOf(i) < 0)
                                collapseList[i] = true;
                        }
                    }
                };

                // Helper checks
                // -----------------------------------
                function isMobile() {
                    return $win.width() < mediaQuery.tablet;
                }

                function isTouch() {
                    return $html.hasClass('touch');
                }

                function isSidebarCollapsed() {
                    return $body.hasClass('aside-collapsed');
                }

                function isSidebarToggled() {
                    return $body.hasClass('aside-toggled');
                }
            }]);
});