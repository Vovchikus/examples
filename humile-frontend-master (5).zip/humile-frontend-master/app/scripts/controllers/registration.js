define([
    'app'
], function (app) {
    'use strict';

    app.controller('RegistrationFormController', [
        '$scope', '$sce',  '$stateParams', 'UserResource', 'Progress',
        function ($scope, $sce, $stateParams, UserResource, Progress) {
            $scope.account = {
                role: 'hr'
            };
            $scope.message = '';
            $scope.messageClass = '';
            $scope.isFormHided = false;

            $scope.register = function (account) {
                Progress.start();

                account.source = $stateParams.source;
                UserResource.registration({data: account}, function (user) {
                    $scope.isFormHided = true;
                    $scope.messageClass = '';
                    $scope.message = 'Вы успешно зарегистрировались! Вскоре вы получите письмо для подтверждения регистрации на ' + account.email;

                    Progress.stop();
                }, function (error) {
                    $scope.messageClass = 'alert-danger';
                    if (error.status === 461) {
                        $scope.message = 'Пользователь с таким логином уже зарегистрирован';
                    } else {
                        $scope.message = 'К сожалению, произошла ошибка. Попробуйте позже или обратитесь в службу поддержки пользователей';
                    }

                    Progress.error();
                });
            };

            $scope.activate = function () {
                if (!$stateParams.user || !$stateParams.code) {
                    $scope.messageClass = 'alert-danger';
                    $scope.message = 'Некорректная ссылка';
                } else {
                    Progress.start();
                    UserResource.activation({id: $stateParams.user, code: $stateParams.code}, function (user) {
                        $scope.isFormHided = true;
                        $scope.messageClass = '';
                        $scope.message = $sce.trustAsHtml('Спасибо! Теперь вы можете <a href="#/page/login">войти в систему</a>');

                        Progress.stop();
                    }, function (error) {
                        $scope.messageClass = 'alert-danger';
                        if (error.status === 462) {
                            $scope.message = 'Активация была произведена ранее';
                        } else {
                            $scope.message = 'К сожалению, произошла ошибка. Попробуйте позже или обратитесь в службу поддержки пользователей';
                        }

                        Progress.error();
                    });
                }
            };

        }]);
});
