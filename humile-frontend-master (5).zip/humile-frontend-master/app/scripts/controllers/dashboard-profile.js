define([
    'app'
], function (app) {
    'use strict';

    /**
     * @param ProfileResource
     * @param Table
     * @constructor
     */
    function DashboardProfileController(ProfileResource, Table) {
        /**
         * Initialization
         */
        function init() {
            vm.table.init(
                ProfileResource.list,
                'id,name,position,description,score',
                true
            );
        }

        /**
         *
         * @param value
         */
        function search(value) {
            vm.table.search(value);
        }

        // DashboardProfileController
        // -----------------------------------
        var vm = this;

        vm.RESULT_OK = 1;
        vm.RESULT_NOT_FOUND = -1;
        vm.RESULT_DEFAULT = 0;

        vm.init = init;
        vm.table = Table;
        vm.search = search;

        vm.result = vm.RESULT_DEFAULT;
        vm.profiles = [];

        vm.init();
    }

    DashboardProfileController.$inject = ['ProfileResource', 'DataTable'];

    app.controller('DashboardProfileController', DashboardProfileController);
});
