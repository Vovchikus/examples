require.config({
    baseUrl: '/scripts',
    urlArgs: 'v=0.01',
    paths:   {
        'jquery':     '../vendor/jquery/dist/jquery.min',
        'underscore': '../vendor/underscore/underscore-min',

        'raven': '../vendor/raven-js/dist/raven.min',

        'angular':          '../vendor/angular/angular',
        'angular-locale':   'vendor/locale',
        'angular-animate':  '../vendor/angular-animate/angular-animate.min',
        'angular-messages': '../vendor/angular-messages/angular-messages.min',
        'angular-cookies':  '../vendor/angular-cookies/angular-cookies.min',
        'angular-resource': '../vendor/angular-resource/angular-resource.min',
        'angular-route':    '../vendor/angular-route/angular-route.min',
        'angular-sanitize': '../vendor/angular-sanitize/angular-sanitize.min',

        'angular-bootstrap':   '../vendor/angular-bootstrap/ui-bootstrap-tpls',
        'angular-drag-n-drop': '../vendor/angular-drag-and-drop-lists/angular-drag-and-drop-lists.min',
        'angular-dialog':      '../vendor/ngDialog/js/ngDialog.min',
        'angular-editable':    'vendor/xeditable/angular-xeditable',

        'angular-ui-router':   '../vendor/angular-ui-router/release/angular-ui-router.min',
        'angular-ui-utils':    '../vendor/angular-ui-utils/ui-utils.min',
        'angular-ui-select':   '../vendor/angular-ui-select/dist/select.min',
        'angular-hotkeys':     '../vendor/angular-hotkeys/build/hotkeys.min',
        'angular-storage':     '../vendor/ngstorage/ngStorage.min',
        'angular-lazy-load':   '../vendor/oclazyload/dist/ocLazyLoad.min',
        'angular-loading-bar': '../vendor/angular-loading-bar/build/loading-bar.min',

        'socket.io': '../vendor/socket.io-client/socket.io',

        'moment':    '../vendor/moment/moment',
        'moment-ru': '../vendor/moment/locale/ru',
        'calendar':  '../vendor/fullcalendar/dist/fullcalendar.min'
    },

    shim: {
        'jquery':   {
            exports: '$'
        },
        'angular':  {
            deps:    ['jquery'],
            exports: 'angular'
        },
        'app':      {
            deps: [
                'jquery',
                'angular'
            ]
        },
        'calendar': {
            deps: [
                'angular',
                'moment'
            ]
        }
    },
    deps: ['bootstrap']
});