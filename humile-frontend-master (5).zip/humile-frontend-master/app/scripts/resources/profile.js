define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("ProfileResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("profiles/:id"),
            calendarURL = Api.buildUrl("profiles/:id/calendar");

        var $cache = $cacheFactory('$profiles');
        var resource = $resource(url, {id: '@id'}, {
            get: {
                cache: $cache
            },
            delete: {
                method: 'DELETE'
            },
            save: {
                method: 'POST',
                cache: $cache
            },
            saveField: {
                method: 'PATCH',
                cache: $cache
            },
            getHistory: {
                url: Api.buildUrl("profiles/:id/history"),
                method: 'GET',
                isArray: true,
                cache: $cache
            },
            addInterview: {
                url: calendarURL,
                method: 'POST',
                cache: $cache
            },
            editInterviewStatus: {
                url: Api.buildUrl("profiles/:id/calendar/status"),
                method: 'PATCH',
                isArray: true,
                cache: $cache
            },
            editInterviewDate: {
                url: Api.buildUrl("profiles/:id/calendar/date"),
                method: 'PATCH',
                cache: $cache
            },
            listInterviews: {
                url: calendarURL,
                method: 'GET',
                isArray: true,
                cache: $cache
            },
            listAllInterviews: {
                url: Api.buildUrl("profiles/calendar"),
                method: 'GET',
                isArray: true,
                cache: $cache
            },
            report: {
                url: Api.buildUrl("profiles/report"),
                method: 'PUT',
                cache: $cache
            },
            _list: {
                url: Api.buildUrl("profiles", []),
                params: {'limit': 100},
                method: 'GET',
                isArray: true,
                cache: $cache
            }
        });

        Api.wrapWithFilters(resource, ['list']);

        var auxiliaryFunctions = {
            clearCache: function () {
                $cache.removeAll();
            }
        };

        return _.extend(resource, auxiliaryFunctions);
    }]);
});