define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("StatsResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("stats/");

        var $cache = $cacheFactory('$stats');
        var resource = $resource(url, {id: '@id'}, {
            profiles: {
                url: Api.buildUrl("stats/profiles"),
                isArray: true,
                cache: $cache
            },
            profileStates: {
                url: Api.buildUrl("stats/profiles/states"),
                isArray: true,
                cache: $cache
            }
        });

        return resource;
    }]);
});