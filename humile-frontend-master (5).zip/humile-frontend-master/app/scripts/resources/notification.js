define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("NotificationResource", ["$resource", "Api", function ($resource, Api) {
        var url = Api.buildUrl("notifications/:id");

        var resource = $resource(url, {id: '@id'}, {
            setViewed: {
                url: Api.buildUrl("notifications/:id/status", []),
                params: {id: '@id', status: 'viewed'},
                method: 'POST',
                isArray: true
            },
            _list: {
                url: Api.buildUrl("notifications", []),
                params: {'limit': 5},
                method: 'GET',
                isArray: true,
                cache: false
            }
        });

        Api.wrapWithFilters(resource, ['list']);

        return _.extend(resource, {});
    }]);
});