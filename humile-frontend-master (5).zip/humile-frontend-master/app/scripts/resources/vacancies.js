define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("VacancyResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("vacancies/:id");

        var $cache = $cacheFactory('$vacancies');
        var resource = $resource(url, {id: '@id'}, {
            get: {
                cache: $cache
            },
            delete: {
                method: 'DELETE'
            },
            save: {
                method: 'POST',
                cache: $cache
            },
            saveField: {
                method: 'PATCH',
                cache: $cache
            },
            addResponse: {
                url: Api.buildUrl("vacancies/:id/response"),
                method: 'POST',
                cache: false
            },
            addResponseComment: {
                url: Api.buildUrl("vacancies/:id/response/:responseId"),
                params: {id: '@id', 'responseId': '@responseId'},
                method: 'POST',
                cache: false
            },
            setResponseStatus: {
                url: Api.buildUrl("vacancies/:id/response/:responseId/status"),
                params: {id: '@id', 'responseId': '@responseId'},
                method: 'POST',
                cache: false
            },
            setResponseProject: {
                url: Api.buildUrl("vacancies/:id/response/:responseId/project"),
                params: {id: '@id', 'responseId': '@responseId'},
                method: 'POST',
                cache: false
            },
            setReplyStatus: {
                url: Api.buildUrl("vacancies/:id/reply/:replyId/status"),
                params: {id: '@id', 'replyId': '@replyId'},
                method: 'POST',
                cache: false
            },
            sendMessage: {
                url: Api.buildUrl("vacancies/message"),
                method: 'PUT'
            },
            _list: {
                url: Api.buildUrl("vacancies", []),
                params: {'limit': 100},
                method: 'GET',
                isArray: true,
                cache: $cache
            }, _listShared: {
                url: Api.buildUrl("vacancies/shared", []),
                params: {'limit': 100},
                method: 'GET',
                isArray: true,
                cache: $cache
            }
        });

        Api.wrapWithFilters(resource, ['list', 'listShared']);

        var auxiliaryFunctions = {
            clearCache: function () {
                $cache.removeAll();
            }
        };

        return _.extend(resource, auxiliaryFunctions);
    }]);
});