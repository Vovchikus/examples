define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("UserResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("users", [":login", ":password", "authorize"]);

        var $cache = $cacheFactory('$users');
        var resource = $resource(url, {login: '@login', password: '@password'}, {
            get:           {
                url:    Api.buildUrl("users", [":id"]),
                params: {id: '@id'},
                method: 'GET',
                cache:  $cache
            },
            delete:        {
                url:    Api.buildUrl("users/:id"),
                params: {id: '@id'},
                method: 'DELETE'
            },
            save:          {
                url:    Api.buildUrl("users", [":id"]),
                method: 'POST',
                cache:  $cache
            },
            saveField:     {
                url:    Api.buildUrl("users", [":id"]),
                method: 'PATCH',
                cache:  $cache
            },
            info:          {
                url:    Api.buildUrl("users/info"),
                method: 'GET',
                cache:  false
            },
            loadMenu:  {
                url:    Api.buildUrl("users/interface/menu"),
                isArray: false,
                method: 'GET',
                cache:  false
            },
            authorize:     {
                method: 'GET',
                cache:  false
            },
            registration: {
                url:    Api.buildUrl("users/registration"),
                method: 'POST',
                cache: false
            },
            activation: {
                url:    Api.buildUrl("users/:id/activation"),
                params: {id: '@id'},
                method: 'POST',
                cache: false
            },
            isExists: {
                url:    Api.buildUrl("users/check"),
                method: 'GET',
                cache: false
            },
            getSettings:   {
                url:    Api.buildUrl("users/settings"),
                method: 'GET',
                cache:  false
            },
            saveSettings:  {
                url:    Api.buildUrl("users/settings"),
                method: 'POST',
                cache:  false
            },
            addCompany:    {
                url:    Api.buildUrl("users/:id/company"),
                method: 'POST',
                cache:  false
            },
            deleteCompany: {
                url:    Api.buildUrl("users/:id/company/:companyId"),
                params: {id: '@id', companyId: '@companyId', role: '@role'},
                method: 'DELETE',
                cache:  false
            },
            listFavourites: {
                url:    Api.buildUrl("users/favourites"),
                method: 'GET',
                cache:  false
            },
            addToFavourites: {
                url:    Api.buildUrl("users/favourites"),
                method: 'PUT',
                cache:  false
            },
            removeFromFavourites: {
                url:    Api.buildUrl("users/favourites"),
                params: {type: '@type', value: '@value'},
                method: 'DELETE',
                cache:  false
            },
            test:          {
                url:    Api.buildUrl("users/settings/email/test"),
                method: 'POST',
                cache:  false
            },
            _list:         {
                url:     Api.buildUrl("users", []),
                params:  {'limit': 100},
                method:  'GET',
                isArray: true,
                cache:   $cache
            }
        });

        Api.wrapWithFilters(resource, ['list']);

        var auxiliaryFunctions = {
            clearCache: function () {
                $cache.removeAll();
            }
        };

        return _.extend(resource, auxiliaryFunctions);
    }]);
});