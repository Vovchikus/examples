define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("ProjectResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("projects/:id");

        var $cache = $cacheFactory('$projects');
        var resource = $resource(url, {id: '@id'}, {
            get: {
                cache: $cache
            },
            delete: {
                method: 'DELETE'
            },
            save: {
                method: 'POST',
                cache: $cache
            },
            saveField: {
                method: 'PATCH',
                cache: $cache
            },
            getHistory: {
                url: Api.buildUrl("projects/:id/history"),
                method: 'GET',
                isArray: true,
                cache: $cache
            },
            saveProfile: {
                url: Api.buildUrl("projects/:id/profile/:profileId", []),
                params: {id: '@id', profileId: '@profileId'},
                method: 'POST',
                cache: $cache
            },
            updateProfile: {
                url: Api.buildUrl("projects/:id/profile/:profileId/:state", []),
                params: {id: '@id', profileId: '@profileId', state: '@state'},
                method: 'POST',
                cache: $cache
            },
            updateProfiles: {
                url: Api.buildUrl("projects/:id/profiles/:state", []),
                params: {id: '@id', state: '@state'},
                method: 'POST',
                cache: $cache
            },
            archiveProfiles: {
                url: Api.buildUrl("projects/:id/profiles/archive", []),
                params: {id: '@id'},
                method: 'POST',
                cache: $cache
            },
            restoreProfiles: {
                url: Api.buildUrl("projects/:id/profiles/restore", []),
                params: {id: '@id'},
                method: 'POST',
                cache: $cache
            },
            getStats: {
                url:  Api.buildUrl("projects/:id/stats", []),
                params: {id: '@id'},
                isArray: true,
                cache: false
            },
            transfer: {
                url:  Api.buildUrl("projects/:id/transfer/:userId", []),
                method: 'POST',
                params: {id: '@id', userId: '@userId'},
                cache: false
            },
            _list: {
                url: Api.buildUrl("projects", []),
                params: {'limit': 100},
                method: 'GET',
                isArray: true,
                cache: $cache
            },
            _profilesList: {
                url: Api.buildUrl("projects/:id/profiles"),
                params: {id: '@id'},
                method: 'GET',
                isArray: true,
                cache: $cache
            }
        });

        Api.wrapWithFilters(resource, ['list', 'profilesList']);

        var auxiliaryFunctions = {
            clearCache: function () {
                $cache.removeAll();
            }
        };

        return _.extend(resource, auxiliaryFunctions);
    }]);
});