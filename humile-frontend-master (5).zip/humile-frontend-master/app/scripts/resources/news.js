define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("NewsResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("news/:id");

        var $cache = $cacheFactory('$news');
        var resource = $resource(url, {id: '@id'}, {
            get: {
                cache: $cache
            },
            delete: {
                method: 'DELETE'
            },
            save: {
                method: 'POST',
                cache: $cache
            },
            saveField: {
                method: 'PATCH',
                cache: $cache
            },
            _list: {
                url: Api.buildUrl("news", []),
                params: {'limit': 100},
                method: 'GET',
                isArray: true,
                cache: $cache
            }
        });

        Api.wrapWithFilters(resource, ['list']);

        var auxiliaryFunctions = {
            clearCache: function () {
                $cache.removeAll();
            }
        };

        return _.extend(resource, auxiliaryFunctions);
    }]);
});