define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("CompanyResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("companies/:id");

        var $cache = $cacheFactory('$companies');
        var resource = $resource(url, {id: '@id'}, {
            get: {
                cache: $cache
            },
            delete: {
                method: 'DELETE'
            },
            save: {
                method: 'POST',
                cache: $cache
            },
            saveField: {
                method: 'PATCH',
                cache: $cache
            },
            _list: {
                url: Api.buildUrl("companies", []),
                params: {'limit': 100},
                method: 'GET',
                isArray: true,
                cache: $cache
            }
        });

        Api.wrapWithFilters(resource, ['list']);

        var auxiliaryFunctions = {
            clearCache: function () {
                $cache.removeAll();
            }
        };

        return _.extend(resource, auxiliaryFunctions);
    }]);
});