define([
    './company',
    './news',
    './notification',
    './profile',
    './project',
    './stats',
    './suggests',
    './user',
    './vacancies'
], function () {});
