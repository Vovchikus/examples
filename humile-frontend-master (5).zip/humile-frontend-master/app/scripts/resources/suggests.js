define(['app', 'underscore'], function (services, _) {
    'use strict';

    services.factory("SuggestsResource", ["$resource", "Api", "$cacheFactory", function ($resource, Api, $cacheFactory) {
        var url = Api.buildUrl("suggests/");

        var $cache = $cacheFactory('$suggests');
        var resource = $resource(url, {}, {
            city: {
                url: Api.buildUrl("suggests/city"),
                params: {'limit': 20, 'name': '@name'},
                isArray: true,
                cache: $cache
            },
            language: {
                url: Api.buildUrl("suggests/language"),
                params: {'limit': 20, 'name': '@name'},
                isArray: true,
                cache: $cache
            },
            _companyOrUser: {
                url: Api.buildUrl("suggests/companyOrUser"),
                params: {},
                isArray: true,
                cache: $cache
            }
        });

        Api.wrapWithFilters(resource, ['companyOrUser']);

        var auxiliaryFunctions = {
            clearCache: function () {
                $cache.removeAll();
            }
        };

        return _.extend(resource, auxiliaryFunctions);
    }]);
});