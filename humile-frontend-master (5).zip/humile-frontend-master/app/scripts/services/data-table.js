define(['app', 'underscore'], function (app, _) {
    'use strict';

    app.factory('DataTable', ['Notify', function (Notify) {
        var service = {};

        service.countPerPageOption = [5, 10, 20, 100];
        service.countPerPage = service.countPerPageOption[1];

        service.currentPage = 1;

        /**
         * Controller's mixin
         */
        service.selectable = {
            selectAll:   function (value) {
                _.map(service.items, function (item) {
                    item.selected = value;
                });
            },
            getSelected: function () {
                return _.filter(service.items, function (item) {
                    return item.selected === true;
                });
            }
        };

        service.init = function (dataResource, fields, preinit) {
            service.count = 0;
            service.value = '';
            service.row = '';
            service.items = [];
            service.filters = {};
            service.isLoaded = false;

            service.data = dataResource;
            service.fields = fields;

            if (!preinit) {
                service.select(1, function () {
                    service.isLoaded = true;
                });
            }
        };

        service.limit = function (limit) {
            service.countPerPage = limit;
        };

        service.run = function () {
            service.select(1, function () {
                service.isLoaded = true;
            });
        };

        service.reload = function () {
            service.select(service.currentPage, function () {
                service.isLoaded = true;
            });
        };

        service.select = function (page, onSelectCallback) {
            service.loadData(page, function () {
                service.currentPage = page;

                if (onSelectCallback) {
                    onSelectCallback();
                }
            });
        };

        service.loadData = function (page, onLoadCallback) {
            var offset = 0;
            if (page) {
                offset = (page - 1) * service.countPerPage || 0;
            }

            var request = {
                search: service.value,
                limit:  service.countPerPage,
                offset: offset,
                filter: service.getFilter(),
                fields: service.fields
            };

            if (service.row) {
                request.orderBy = service.row;
            }

            service.data(request, function (data, getHeaders) {
                service.items = data;
                service.count = getHeaders('x-count');

                if (onLoadCallback) {
                    onLoadCallback();
                }

            }, function () {
                Notify.error(Notify.REQUEST_ERROR);
            });

        };

        service.getPagesCount = function () {
            return Math.ceil(service.count / service.countPerPage);
        };

        service.onFilterChange = function () {
            return service.select(1);
        };

        service.onCountPerPageChange = function () {
            return service.select(1);
        };

        service.search = function (value) {
            service.value = value;

            service.isLoaded = true;
            return service.select(1);
        };

        service.addFilter = function (field, value) {
            service.filters[field] = value;

            return service.select(1);
        };

        service.removeFilter = function (field) {
            if (service.filters.hasOwnProperty(field)) {
                delete service.filters[field];

                return service.select(1);
            }
        };

        service.getFilter = function () {
            return service.filters;
        };

        service.order = function (row) {
            service.row = row;
            service.select(service.currentPage);
        };

        return service;
    }]);
});