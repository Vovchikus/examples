define([
    './browser',
    './nav-search',
    './progress',
    './toggle-state',
    './utils'
], function () {});
