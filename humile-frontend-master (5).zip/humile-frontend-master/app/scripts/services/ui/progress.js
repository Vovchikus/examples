define([
    'app'
], function (app) {
    'use strict';
    app.service('Progress', ['$rootScope', '$timeout', function ($rootScope, $timeout) {
        function startProgress() {
            $rootScope.showProgress = true;
        }

        function stopProgress() {
            $rootScope.showProgress = false;
        }

        function errorWhileProgress() {
            $rootScope.showProgress = -1;
            $timeout(function () {
                stopProgress();
            }, 1000);
        }

        return {
            start: startProgress,
            stop:  stopProgress,
            error: errorWhileProgress
        };
    }]);
});




