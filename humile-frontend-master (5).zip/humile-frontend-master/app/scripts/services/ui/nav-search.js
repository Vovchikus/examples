define([
    'app'
], function (app) {
    'use strict';

    app.service('navSearch', [
        function () {
            var navbarFormSelector = 'form.navbar-form';
            return {
                toggle: function () {
                    var navbarForm = $(navbarFormSelector);
                    navbarForm.toggleClass('open');
                    var isOpen = navbarForm.hasClass('open');
                    navbarForm.find('input')[isOpen ? 'focus' : 'blur']();
                },

                dismiss: function () {
                    $(navbarFormSelector)
                        .removeClass('open')
                        .find('input[type="text"]').blur()
                        .val('');
                }
            };
        }
    ]);
});





