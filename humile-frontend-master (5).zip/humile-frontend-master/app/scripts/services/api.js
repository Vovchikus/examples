define(['app', 'angular', 'underscore'], function (app, ng, _) {
    'use strict';

    app.factory("Api", ["$location", "SETTINGS", function ($location, SETTINGS) {
        var service = {}, host = $location.host();

        if (host === 'localhost') { // Dev environment hack
            host = 'humile.dev';
        }

        service.api = {
            version: "v1",
            host: "//api." + host.replace(SETTINGS.application.domain + ".", ""),
            statics: "//static." + host.replace(SETTINGS.application.domain + ".", "")
        };

        /**
         * Returns base Api URL
         * @returns {*}
         */
        service.getBaseUrl = function () {
            return service.api.host;
        };

        /**
         * Build Api URL
         *
         * @param method
         * @param args
         * @returns {string}
         */
        service.buildUrl = function (method, args) {
            var url = service.api.host + "/" + service.api.version + "/" + method;
            url = service.addQueryParams(url, args);
            return url;
        };

        /**
         * @param url
         * @param args
         * @returns {*}
         */
        service.addQueryParams = function (url, args) {
            ng.forEach(args, function (v, k) {
                var sign = "?";
                if (typeof k === 'string') {
                    if (url.indexOf('?') !== -1) {
                        sign = "&";
                    }
                    url += sign + k + "=" + v;
                } else {
                    url += "/" + v;
                }
            });

            return url;
        };

        /**
         * Put {"name": "value"} filters to API-acceptable form
         * @param filters
         * @returns {string}
         */
        service.composeFilters = function (filters) {
            var composed = [];

            ng.forEach(filters, function (value, name) {
                composed.push(name + "=" + value);
            });

            return composed.join(',');
        };

        /**
         * Wraps resource actions for auto-composing "filter" field.
         * Original function must be underscored.
         *
         * @param resource
         * @param functions
         * @returns {*}
         */
        service.wrapWithFilters = function (resource, functions) {
            ng.forEach(functions, function (name) {
                var original = resource['_' + name];

                resource[name] = function (data, success, error) {
                    if (_.isObject(data.filter) && !_.isEmpty(data.filter)) {
                        data.filter = service.composeFilters(data.filter);
                    }
                    return original(data, success, error);
                };
            });

            return resource;
        };

        return service;
    }]);
});