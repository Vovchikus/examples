define(['app', 'angular', 'underscore'], function (app, ng, _) {
    'use strict';

    app.factory('Auth', [
        '$rootScope',
        '$localStorage',
        '$cacheFactory',
        'SETTINGS',
        function ($rootScope, $localStorage, $cacheFactory, SETTINGS) {
            var service = {}, storage = $localStorage;

            /**
             * Login
             * @param token
             */
            service.login = function (data) {
                storage.user = {
                    token: data.token
                };
            };

            service.isAuthorized = function () {
                var isAuthorized = true;

                if (_.isEmpty(storage.user)) {
                    isAuthorized = false;
                }

                return isAuthorized;
            };

            /**
             * Logout
             */
            service.logout = function () {
                service.cleanUp();

                var cacheFactories = SETTINGS.cacheFactories;
                _.forEach(cacheFactories, function (v) {
                    var cache = $cacheFactory.get(v);
                    if (cache !== undefined) {
                        cache.removeAll();
                    }
                });

                $rootScope.$state.go('page.login');
            };

            service.setData = function (data) {
                _.extend(storage.user, data);
            };

            /**
             * Usage: <element ng-if="user.is.admin()"></element>
             * @type {{admin: Function, hr: Function, customer: Function}}
             */
            service.is = {
                admin:    function () {
                    return service.getRole() === 'admin';
                },
                hr:       function () {
                    return service.getRole() === 'hr';
                },
                customer: function () {
                    return service.getRole() === 'customer';
                }
            };

            service.hasId = function (id) {
                return service.getId() === id;
            };

            service.roleIn = function (roles) {
                if (_.isArray(roles)) {
                    return roles.indexOf(service.getRole()) !== -1;
                }

                return false;
            };

            service.can = function (action) {
                var result = false;
                try {
                    var permissions = storage.user.permissions;

                    result = permissions;
                    ng.forEach(action.split('.'), function (value) {
                        result = result[value];
                    });
                } catch (e) {}

                return Boolean(result);
            };

            service.getId = function () {
                var id = {};
                try {
                    id = storage.user.id;
                } catch (e) {
                }

                return id;
            };

            service.getLogin = function () {
                var login = {};
                try {
                    login = storage.user.login;
                } catch (e) {
                }

                return login;
            };

            service.getName = function () {
                var name = {};
                try {
                    name = storage.user.name;
                } catch (e) {
                }

                return name;
            };

            service.getRole = function () {
                var role = '';
                try {
                    role = storage.user.role;
                } catch (e) {
                }

                return role;
            };

            service.getToken = function () {
                var token = '';
                try {
                    token = storage.user.token;
                } catch (e) {
                }

                return token;
            };

            service.getImage = function () {
                var image = '';
                try {
                    image = storage.user.image || '/assets/img/dummy.png';
                } catch (e) {
                }

                return image;
            };

            service.cleanUp = function () {
                $localStorage.$reset();
            };

            return service;
        }]);
});