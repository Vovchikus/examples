define([
    './api',
    './auth',
    './data-table',
    './downloader',
    './notify',
    './ui/index'
], function () {});