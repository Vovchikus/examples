define([
    './controllers/list',
    './controllers/search',
    './controllers/view'
], function () {});
