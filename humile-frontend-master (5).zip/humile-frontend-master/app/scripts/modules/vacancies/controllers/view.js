define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     * @param $rootScope
     * @param VacancyResource
     * @param ProjectResource
     * @param Dialog
     * @param Auth
     * @param Notify
     * @constructor
     */
    function VacancyViewController($rootScope, VacancyResource, ProjectResource, Dialog, Auth, Notify) {
        /**
         *
         * @param item
         */
        function updateItemView(item) {
            vm.item = item;
            if (Auth.is.hr()) {
                vm.myResponse = _.reduce(
                    vm.item.responses,
                    function (previous, current) {
                        return current;
                    },
                    null
                );
            }

            vm.item.groupedReplies = {
                'new': [],
                'accepted': [],
                'declined': []
            };
            _.forEach(vm.item.replies, function(reply) {
                vm.item.groupedReplies[reply.status].push(reply);
            });
        }

        /**
         * @param id
         */
        function loadVacancy(id) {
            VacancyResource.get({
                'id':     id,
                'fields': 'id,title,description,experience,bonuses,placement,type,schedule,city,wage,published,cost,deadline,status,permissions,responses,replies,stats'
            }, function (item) {
                updateItemView(item);
                vm.isLoaded = true;
            });
        }

        /**
         * @param comment
         */
        function sendResponse(comment) {
            VacancyResource.addResponse({
                id:      vm.id,
                comment: comment
            }, function (item) {
                VacancyResource.clearCache();
                updateItemView(item);
            });
        }

        /**
         * @param responseId
         * @param comment
         */
        function addComment(responseId, comment) {
            VacancyResource.addResponseComment({
                id:         vm.id,
                responseId: responseId,
                comment:    comment
            }, function (item) {
                VacancyResource.clearCache();
                updateItemView(item);
            });
        }

        /**
         * @param status
         * @param response
         */
        function setResponseStatus(status, response) {
            VacancyResource.setResponseStatus({
                id:         vm.id,
                responseId: response.id,
                status:     status,
                userId:     response.user.id,
                userName:   response.user.name
            }, function (item) {
                VacancyResource.clearCache();
                updateItemView(item);
            });
        }

        /**
         * @param status
         * @param reply
         */
        function setReplyStatus(status, reply) {
            VacancyResource.setReplyStatus({
                id:      vm.id,
                replyId: reply.id,
                status:  status
            }, function (item) {
                VacancyResource.clearCache();
                updateItemView(item);
            });

            if (status === 'declined') {
                sendMessage(reply);
            }
        }

        function sendMessage(reply) {
            var email = '';
            _.forEach(reply.profile.contacts, function (contact) {
                if (contact.type === 'email') {
                    email = contact.value;
                }
            });

            var scope = $rootScope.$new();
            scope.report = {
                email:   email,
                subject: 'Спасибо за ваш отклик',
                content: 'Уважаемый ' + reply.profile.name.last + ' ' + reply.profile.name.first + '!\n\n' +
                         'Спасибо за ваш отклик на вакансию: "' + vm.item.title + '"!\n' +
                         'К сожалению, вы нам не подходите.\n\n' +
                         'С уважением, ' + Auth.getName() + '.'
            };

            return Dialog.openConfirm({
                template:         'template/sendToEmailDialogue',
                preCloseCallback: 'preCloseCallbackOnScope',
                closeByDocument:  true,
                closeByEscape:    true,
                scope:            scope
            }).then(function (report) {
                VacancyResource.sendMessage(report, function () {
                    Notify.success('Письмо отправлено на <i>' + report.email + '</i>');
                });
            });
        }

        /**
         *
         * @param reply
         * @returns {*}
         */
        function addToProject(reply)
        {
            var scope = $rootScope.$new();
            scope.id = reply.profile.id;

            return Dialog.openConfirm({
                template:         '/scripts/modules/profiles/views/dialogs/project.html',
                preCloseCallback: 'preCloseCallbackOnScope',
                closeByDocument:  true,
                closeByEscape:    true,
                scope:            scope
            }).then(function (projectName) {
                Notify.success('Профиль успешно добавлен в проект <b>' + projectName + '</b>!');
            });
        }
        /**
         *
         * @param responseId
         * @param name
         */
        function createProject(responseId, name) {
            ProjectResource.save({data: {name: name}}, function (data) {
                VacancyResource.setResponseProject({
                    id:         vm.id,
                    responseId: responseId,
                    project:    data.id
                }, function (item) {
                    VacancyResource.clearCache();
                    updateItemView(item);

                    Notify.success(Notify.SUCCESS);
                });

                ProjectResource.clearCache();
            });
        }

        function selectProject(responseId) {
            var scope = $rootScope.$new();

            ProjectResource.list({'fields': 'id, name, permissions'}, function (projects) {
                scope.projects = projects.filter(function (project) {
                    return project.permissions.edit === true;
                });
            });

            return Dialog.openConfirm({
                template:         'template/selectProjectDialogue',
                preCloseCallback: 'preCloseCallbackOnScope',
                className:        'ngdialog-theme-default',
                closeByDocument:  true,
                closeByEscape:    true,
                scope:            scope
            }).then(function (projectId) {
                VacancyResource.setResponseProject({
                    id:         vm.id,
                    responseId: responseId,
                    project:    projectId
                }, function (item) {
                    VacancyResource.clearCache();
                    updateItemView(item);

                    Notify.success(Notify.SUCCESS);
                });
            });
        }

        /**
         * Initialization
         */
        function init() {
            $rootScope.checkAccess(['admin', 'customer', 'hr']);
            loadVacancy(vm.id);
        }

        // VacancyViewController
        // -----------------------------------
        var vm = this;

        vm.id = $rootScope.$stateParams.id;
        vm.item = {};
        vm.isLoaded = false;
        vm.myResponse = null;
        vm.init = init;
        vm.sendResponse = sendResponse;
        vm.addComment = addComment;
        vm.setResponseStatus = setResponseStatus;
        vm.setReplyStatus = setReplyStatus;
        vm.addToProject = addToProject;
        vm.sendMessage = sendMessage;
        vm.collapsed = {};

        vm.createProject = createProject;
        vm.selectProject = selectProject;

        vm.init();
    }

    VacancyViewController.$inject = ['$rootScope', 'VacancyResource', 'ProjectResource', 'ngDialog', 'Auth', 'Notify'];
    app.controller('VacancyViewController', VacancyViewController);
});