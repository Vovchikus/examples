define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param Table
     * @param VacancyResource
     * @param Dialog
     * @param Notify
     * @constructor
     */
    function VacancyListController($rootScope, Table, VacancyResource, Dialog, Notify) {
        /**
         *
         */
        function init() {
            $rootScope.checkAccess(['admin', 'customer', 'hr']);

            vm.table.init(
                VacancyResource.list,
                'id,title,description,experience,bonuses,placement,type,schedule,city,wage,published,cost,deadline,status,permissions'
            );
        }

        /**
         *
         * @param data
         * @returns {*}
         */
        function beforeSave(data) {
            var updated = _.clone(data);

            if (updated.deadline instanceof Date && !isNaN(updated.deadline.valueOf())) {
                updated.deadline = updated.deadline.toISOString();
            }

            return updated;
        }

        /**
         * @param scope
         * @param template
         * @param className
         * @returns {*}
         */
        function getDialogue(scope, template, className) {
            scope = _.extend($rootScope.$new(), scope);

            return Dialog.openConfirm({
                template:         template,
                preCloseCallback: 'preCloseCallbackOnScope',
                className:        className || 'ngdialog-theme-default',
                closeByDocument:  true,
                closeByEscape:    true,
                scope:            scope
            });
        }

        function createVacancy() {
            getDialogue({
                isNew:      true,
                item:       {
                    status: 'draft'
                },
                datepicker: vm.datepicker
            }, 'template/vacancyEditDialog', 'ngdialog-theme-default ngdialog-wide')
                .then(function (data) {
                    VacancyResource.save({data: beforeSave(data)}, function () {
                        Notify.success(Notify.SUCCESS);
                        VacancyResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        function editVacancy(item) {
            getDialogue({
                isNew:      false,
                item:       item,
                datepicker: vm.datepicker
            }, 'template/vacancyEditDialog', 'ngdialog-theme-default ngdialog-wide')
                .then(function (data) {
                    VacancyResource.save({id: item.id}, {data: beforeSave(data)}, function () {
                        Notify.success(Notify.SUCCESS);
                        VacancyResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        function deleteVacancy(item) {
            getDialogue({item: item}, 'template/vacancyDeleteDialog')
                .then(function (id) {
                    VacancyResource.delete({id: id}, function () {
                        Notify.success(Notify.SUCCESS_DELETED);
                        VacancyResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        // VacancyListController
        // -----------------------------------
        var vm = this;
        vm.init = init;
        vm.table = Table;

        vm.create = createVacancy;
        vm.edit = editVacancy;
        vm.delete = deleteVacancy;

        vm.datepicker = {
            opened: [ false, false ],
            open:   function ($event, index) {
                $event.preventDefault();
                $event.stopPropagation();

                vm.datepicker.opened[index] = true;
            }
        };

        vm.init();
    }

    VacancyListController.$inject = ['$rootScope', 'DataTable', 'VacancyResource', 'ngDialog', 'Notify'];
    app.controller('VacancyListController', VacancyListController);
});