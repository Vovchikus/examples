define(['app'], function (app) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param Table
     * @param VacancyResource
     * @param Dialog
     * @param Notify
     * @constructor
     */
    function SearchVacanciesController($rootScope, Table, VacancyResource, Dialog, Notify) {
        /**
         * Initialization
         */
        function init() {
            $rootScope.checkAccess(['hr', 'admin']);


            vm.table.init(
                VacancyResource.listShared,
                'id,title,description,created,cost,deadline,city,score',
                true
            );
            vm.table.run();
        }

        function search(value) {
            vm.table.search(value);
        }

        // SearchVacanciesController
        // -----------------------------------
        var vm = this;
        vm.init = init;
        vm.table = Table;
        vm.search = search;

        vm.init();
    }

    SearchVacanciesController.$inject = ['$rootScope', 'DataTable', 'VacancyResource', 'ngDialog', 'Notify'];
    app.controller('SearchVacanciesController', SearchVacanciesController);
});