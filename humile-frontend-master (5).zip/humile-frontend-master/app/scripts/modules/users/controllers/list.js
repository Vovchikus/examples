define(['app'], function (app) {
    'use strict';

    app.controller("UserListCtrl", [
        "$scope",
        "DataTable",
        "UserResource",
        "ngDialog",
        "Notify",
        function ($scope, Table, UserResource, Dialog, Notify) {
            $scope.table = Table;
            $scope.table.init(UserResource.list, 'id, role, login, name, status');

            $scope.delete = function (item) {
                var scope = $scope.$new(true);
                scope.item = item;

                Dialog.openConfirm({
                    template: 'template/deleteDialog',
                    preCloseCallback: 'preCloseCallbackOnScope',
                    scope: scope
                }).then(function (id) {
                    UserResource.delete({id: id}, function () {
                        Notify.success(Notify.SUCCESS_DELETED);
                        UserResource.clearCache();
                        $scope.table.reload();
                    });
                });
            };
        }
    ]);
});