define(['app', 'underscore'], function (app, _) {
    'use strict';

    app.controller("UserViewController", [
        "$scope",
        "$rootScope",
        "UserResource",
        "CompanyResource",
        "Notify",
        function ($scope, $rootScope, UserResource, CompanyResource, Notify) {
            var id = $rootScope.$stateParams.id;

            $scope.isNew = (_.isNull(id) ? true : false);

            $rootScope.checkAccess('admin');

            if (!$scope.isNew) {
                UserResource.get({id: id}, function (user) {
                    $scope.item = user;
                }, function () {
                    Notify.error(Notify.REQUEST_ERROR);
                });
            }

            var statuses = [
                {'code': -1, 'name': 'Заблокирован'},
                {'code': 0, 'name': 'Неактивен'},
                {'code': 1, 'name': 'Активен'}
            ];

            $scope.getStatuses = function () {
                return statuses;
            };

            $scope.save = function () {
                if (!_.isUndefined($scope.item.password) && $scope.item.password.length === 0) { // A little hack
                    $scope.item.password = undefined;
                }

                UserResource.save({id: $scope.item.id}, $scope.item, function (item) {
                    $scope.error = "";
                    Notify.success(Notify.SUCCESS_SAVED);
                    UserResource.clearCache();

                    if ($scope.isNew) {
                        $rootScope.$state.go('app.user', {id: item.id});
                    }
                }, function (error) {
                    $scope.error = "Внимание! Данные не были сохранены!";
                    if (error.status === 461) {
                        Notify.error("Пользователь с таким логином уже существует в системе!");
                    } else {
                        Notify.error(Notify.SAVE_REQUEST_ERROR);
                    }
                });
            };

            $scope.getCompanies = function (value) {
                return CompanyResource.list({
                    filter: {'name': value},
                    fields: 'id, name'
                }).$promise.then(
                    function (response) {
                        return response;
                    }
                );
            };

            $scope.addCompany = function (company, role) {
                var companyData = {
                    id:   company.id,
                    name: company.name,
                    role: role
                };

                UserResource.addCompany({id: id}, {company: companyData}, function () {
                    Notify.success(Notify.SUCCESS);
                    UserResource.clearCache();


                    $scope.item.companies.push(companyData);
                });
            };

            $scope.deleteCompany = function (company, index) {
                UserResource.deleteCompany({id: id, companyId: company.id, role: company.role}, function () {
                    Notify.success(Notify.SUCCESS);
                    UserResource.clearCache();

                    $scope.item.companies.splice(index, 1);
                });
            };
        }
    ]);
});