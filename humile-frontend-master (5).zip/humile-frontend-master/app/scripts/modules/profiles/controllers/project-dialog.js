define(['app'], function (app) {
    'use strict';

    app.controller('ProfileProjectDialogCtrl', [
        '$scope',
        'ProjectResource',
        function ($scope, ProjectResource) {

            var filter = {};
            filter['profiles.' + $scope.$parent.id] = 'exists:true';

            ProjectResource.list({
                'fields': 'id, name',
                'filter': filter
            }, function (projects) {
                $scope.activeProjects = projects;
            });

            ProjectResource.list({'fields': 'id, name, permissions'}, function (projects) {
                $scope.projects = projects.filter(function (pkg) {
                    return pkg.permissions.edit === true;
                });
            });

            $scope.projectData = {};
            $scope.add = function (profileId, projectData) {
                ProjectResource.saveProfile({id: projectData.selected.id, profileId: profileId}, function () {
                    ProjectResource.clearCache();
                    $scope.$parent.confirm(projectData.selected.name);
                });
            };
        }
    ]);
});