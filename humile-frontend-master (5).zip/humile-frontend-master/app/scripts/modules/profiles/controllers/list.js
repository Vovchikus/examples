define(['app'], function (app) {
    'use strict';

    app.controller("ProfileListCtrl", [
        "$rootScope",
        "$scope",
        "DataTable",
        "ProfileResource",
        "ngDialog",
        "Notify",
        function ($rootScope, $scope, Table, ProfileResource, Dialog, Notify) {
            $rootScope.checkAccess(['admin', 'hr']);

            $scope.table = Table;
            $scope.table.init(ProfileResource.list, 'id, name, source, permissions');

            $scope.delete = function (item) {
                var scope = $scope.$new(true);
                scope.item = item;

                Dialog.openConfirm({
                    template: 'template/deleteDialog',
                    preCloseCallback: 'preCloseCallbackOnScope',
                    closeByDocument: true,
                    closeByEscape: true,
                    scope: scope
                }).then(function (id) {
                    ProfileResource.delete({id: id}, function () {
                        Notify.success(Notify.SUCCESS_DELETED);
                        ProfileResource.clearCache();
                        $scope.table.reload();
                    });
                });
            };

            $scope.create = function () {
                Dialog.openConfirm({
                    template: 'template/createDialog',
                    preCloseCallback: 'preCloseCallbackOnScope',
                    closeByDocument: true,
                    closeByEscape: true
                }).then(function (name) {
                    ProfileResource.save({data: {name: name}}, function () {
                        Notify.success(Notify.SUCCESS);
                        ProfileResource.clearCache();
                        $scope.table.reload();
                    });
                });

            };
        }
    ]);
});