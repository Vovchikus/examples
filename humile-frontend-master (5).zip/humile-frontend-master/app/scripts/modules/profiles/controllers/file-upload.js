define(['app'], function (app) {
    'use strict';

    app.controller("FileUploadCtrl", [
        "$scope",
        "Upload",
        "Api",
        function ($scope, Upload, Api) {
            $scope.files = [];

            $scope.removeFile = function (index) {
                $scope.files.splice(index, 1);
            };

            $scope.upload = function (files) {
                var remains = files.length, uploaded = [],
                    checkIsReady = function (file) {
                        remains -= 1;
                        uploaded.push(file);

                        return remains === 0;
                    },
                    sendResponse = function () {
                        $scope.$parent.confirm(uploaded); // Close ngDialog
                    };

                if (files && files.length) {
                    for (var i = 0; i < files.length; i++) {
                        var file = files[i];
                        Upload.upload({
                            url:  Api.buildUrl("documents/" + $scope.$parent.id),
                            file: file
                        }).success(function (data, status, headers, config) {
                            if (checkIsReady(data)) {
                                sendResponse();
                            }
                        });
                    }
                }
            };

        }
    ]);
});