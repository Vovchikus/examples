define(['app', 'underscore'], function (app, _) {
    'use strict';

    function ProfileHistoryController($rootScope, ProfileResource, ProfileProperties, Progress) {

        /**
         *
         * @param id
         */
        function init(id) {
            Progress.start();

            ProfileResource.get({id: id, 'fields': 'id,name,source,permissions,fullPermissions'}, function (profile) {
                vm.profile = profile;

                ProfileResource.getHistory({id: id}, function (items) {
                    vm.items = items;
                    vm.isLoaded = true;
                    Progress.stop();
                }, function () {
                    Progress.error();
                });
            }, function () {
                Progress.error();
            });


        }

        // ProfileHistoryController
        // -----------------------------------
        var vm = this;

        vm.id = $rootScope.$stateParams.id;

        vm.profile = {};
        vm.items = [];
        vm.isLoaded = false;
        vm.properties = ProfileProperties;

        init(vm.id);
    }

    ProfileHistoryController.$inject = ['$rootScope', 'ProfileResource', 'ProfileProperties', 'Progress'];
    app.controller('ProfileHistoryController', ProfileHistoryController);
});