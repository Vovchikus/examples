define(['app', 'underscore', 'angular'], function (app, _, ng) {
    'use strict';

    app.controller('ProfileViewCtrl', [
        '$scope',
        '$rootScope',
        '$filter',
        'SuggestsResource',
        'ProfileResource',
        'ProfileData',
        'ProfileProperties',
        'Notify',
        'Progress',
        'Api',
        'Downloader',
        'Upload',
        'ngDialog',
        'Auth',
        function ($scope, $rootScope, $filter, SuggestsResource, ProfileResource, ProfileData, ProfileProperties, Notify, Progress, Api, Downloader, Upload, Dialog, Auth) {
            var id = $rootScope.$stateParams.id;

            $scope.isNew = (_.isNull(id) ? true : false);
            $scope.isLoaded = false;
            $scope.isInterviewsLoaded = false;
            $scope.interviews = [];

            $rootScope.checkAccess(['admin', 'hr']);

            $scope.properties = ProfileProperties;

            $scope.loadInterviews = function() {
                ProfileResource.listInterviews({id: id}, function (interviews) {
                    $scope.interviews = interviews;
                    $scope.isInterviewsLoaded = true;
                });
            };

            if (!$scope.isNew) {
                ProfileResource.get({id: id}, function (profile) {
                    $scope.item = ProfileData.prepare(profile);
                    $scope.isLoaded = true;

                    $scope.loadInterviews();
                }, function () {
                    Notify.error(Notify.REQUEST_ERROR);
                });
            }

            var getDialogue = function (scope, template) {
                scope = _.extend($scope.$new(), scope);

                template = '/scripts/modules/profiles/views/dialogs/' + template + '.html';
                return Dialog.openConfirm({
                    template:         template,
                    preCloseCallback: 'preCloseCallbackOnScope',
                    closeByDocument:  true,
                    closeByEscape:    true,
                    scope:            scope
                });
            };

            $scope.getCitySuggestions = function (name) {
                return SuggestsResource.city({
                    name:  name,
                    limit: 10
                }).$promise.then(
                    function (response) {
                        return response;
                    }
                );
            };

            // GENDER
            // -----------------------------------
            $scope.showGender = function () {
                var selected = $filter('filter')(ProfileProperties.genders, {value: $scope.item.gender});
                return ($scope.item.gender && selected.length) ? selected[0].text : 'Пол';
            };

            // MARITAL STATUS
            // -----------------------------------
            $scope.showMaritalStatus = function () {
                var selected = $filter('filter')(ProfileProperties.maritalStatuses, {value: $scope.item.maritalStatus});
                return ($scope.item.maritalStatus && selected.length) ? (selected[0].text[$scope.item.gender] || selected[0].text.default) : 'Сем. положение';
            };

            // EDUCATIONAL LEVEL
            // -----------------------------------
            $scope.showEducationalLevel = function (level) {
                var selected = $filter('filter')(ProfileProperties.educationLevel, {value: level});
                return selected[0].text;
            };

            // LANGUAGE LEVEL
            // -----------------------------------
            $scope.showLanguageLevel = function (level) {
                var selected = $filter('filter')(ProfileProperties.languageLevel, {value: level});
                return selected[0].text;
            };

            // PHOTO UPLOADING
            // -----------------------------------
            $scope.uploadPhoto = function (files) {
                if (files && files.length) {
                    var file = files[0];
                    Progress.start();
                    Upload.upload({
                        url:  Api.buildUrl('documents/photo/'),
                        file: file
                    }).success(function (data) {
                        $scope.item.photo = data;
                        $scope.saveField('photo', data);

                        Progress.stop();
                    }, function() {
                        Progress.error();
                    });
                }
            };

            // ADD TO PROJECT DIALOG
            // -----------------------------------
            $scope.addToProject = function (id) {
                var scope = {
                    id: id
                };

                getDialogue(scope, 'project').then(function (projectName) {
                    Notify.success('Профиль успешно добавлен в проект <b>' + projectName + '</b>!');
                });
            };

            // SKILLS DIALOG
            // -----------------------------------
            $scope.addSkill = function () {
                getDialogue({}, 'skill').
                    then(function (skill) {
                        $scope.addItemToArrayField('skills', skill);
                        $scope.saveField('skills', $scope.item.skills);
                    });
            };

            // CONTACTS DIALOG
            // -----------------------------------
            $scope.addContact = function () {
                getDialogue({isNew: true}, 'contact').
                    then(function (contact) {
                        contact.status = 1;
                        contact.source = 'humile';

                        $scope.addItemToArrayField('contacts', contact);
                        $scope.saveField('contacts', $scope.item.contacts);
                    });
            };

            $scope.editContact = function (contact, index) {
                var scope = {
                    isNew:   false,
                    contact: contact,
                    index:   index,
                    remove:  function (index) {
                        $scope.removeItemFromArrayField('contacts', index);
                        $scope.saveField('contacts', $scope.item.contacts);

                        return true;
                    }
                };

                getDialogue(scope, 'contact').
                    then(function () {
                        $scope.saveField('contacts', $scope.item.contacts);
                    });
            };

            // INTERVIEW DIALOG
            // -----------------------------------
            $scope.addInterview = function () {
                var scope = {
                    isNew:  true,
                    interview: {
                        date: new Date()
                    },
                    opened: [],
                    open:   function ($event, index) {
                        $event.preventDefault();
                        $event.stopPropagation();

                        scope.opened[index] = true;
                    }
                };

                getDialogue(scope, 'interview').
                    then(function (interview) {
                        ProfileResource.addInterview({id: id, date: interview.date}, function (interview) {
                            ProfileResource.clearCache();

                            $scope.interviews.push(interview);
                        });
                    });
            };

            $scope.editInterviewStatus = function (interview, index) {
                var scope = {
                    isNew:     false,
                    interview: interview,
                    opened:    [],
                    open:      function ($event, index) {
                        $event.preventDefault();
                        $event.stopPropagation();

                        scope.opened[index] = true;
                    }
                };

                getDialogue(scope, 'interview').
                    then(function (interview) {
                        ProfileResource.editInterviewStatus(
                            {id: id},
                            {
                                interviewId: interview.id,
                                status:      interview.status,
                                comment:     interview.comment
                            },
                            function (interviews) {
                                $scope.interviews = interviews;
                                ProfileResource.clearCache();
                            }
                        );
                    });
            };

            // LANGUAGES DIALOG
            // -----------------------------------
            function getLanguageSuggestions(name) {
                return SuggestsResource.language({
                    name: name
                }).$promise.then(
                    function (response) {
                        return response;
                    }
                );
            }

            $scope.addLanguage = function () {
                getDialogue({
                    isNew:                  true,
                    getLanguageSuggestions: getLanguageSuggestions
                }, 'language').
                    then(function (language) {
                        $scope.addItemToArrayField('languages', language);
                        $scope.saveField('languages', $scope.item.languages);
                    });
            };

            $scope.editLanguage = function (language, index) {
                var scope = {
                    isNew:                  false,
                    getLanguageSuggestions: getLanguageSuggestions,
                    language:               language,
                    index:                  index,
                    remove:                 function (index) {
                        $scope.removeItemFromArrayField('languages', index);
                        $scope.saveField('languages', $scope.item.languages);

                        return true;
                    }
                };

                getDialogue(scope, 'language').
                    then(function () {
                        $scope.saveField('languages', $scope.item.languages);
                    });
            };

            // EXPERIENCE DIALOG
            // -----------------------------------
            $scope.addExperience = function () {
                var scope = {
                    isNew:  true,
                    opened: [],
                    open:   function ($event, index) {
                        $event.preventDefault();
                        $event.stopPropagation();

                        scope.opened[index] = true;
                    }
                };

                getDialogue(scope, 'experience').
                    then(function (experience) {
                        var field = ng.copy($scope.item.experience) || [];
                        field.push(experience);

                        $scope.saveField('experience', field, true);
                    });
            };

            $scope.editExperience = function (experience, index) {
                var scope = {
                    isNew:      false,
                    experience: ng.copy(experience),
                    index:      index,
                    remove:     function (index) {
                        $scope.removeItemFromArrayField('experience', index);
                        $scope.saveField('experience', $scope.item.experience);

                        return true;
                    },
                    opened:     [],
                    open:       function ($event, index) {
                        $event.preventDefault();
                        $event.stopPropagation();

                        scope.opened[index] = true;
                    }
                };

                getDialogue(scope, 'experience').
                    then(function (experience) {
                        var field = ng.copy($scope.item.experience);
                        field[index] = experience;

                        $scope.saveField('experience', field, true);
                    });
            };

            // EDUCATION DIALOG
            // -----------------------------------
            $scope.addEducation = function () {
                var scope = {
                    isNew:  true,
                    opened: [],
                    open:   function ($event, index) {
                        $event.preventDefault();
                        $event.stopPropagation();

                        scope.opened[index] = true;
                    }
                };

                getDialogue(scope, 'education').
                    then(function (education) {
                        var field = ng.copy($scope.item.education) || [];
                        field.push(education);

                        $scope.saveField('education', field, true);
                    });
            };

            $scope.editEducation = function (education, index) {
                var scope = {
                    isNew:     false,
                    education: ng.copy(education),
                    index:     index,
                    remove:    function (index) {
                        $scope.removeItemFromArrayField('education', index);
                        $scope.saveField('education', $scope.item.education);

                        return true;
                    },
                    opened:    [],
                    open:      function ($event, index) {
                        $event.preventDefault();
                        $event.stopPropagation();

                        scope.opened[index] = true;
                    }
                };

                getDialogue(scope, 'education').
                    then(function (education) {
                        var field = ng.copy($scope.item.education);
                        field[index] = education;

                        $scope.saveField('education', field, true);
                    });
            };

            // BIRTHDAY DIALOG
            // -----------------------------------
            $scope.editBirthday = function () {
                getDialogue({birthday: $scope.item.birthday}, 'birthday').
                    then(function (birthday) {
                        $scope.item.birthday = birthday;
                        $scope.saveField('birthday', birthday);
                    });
            };

            // COMMENTS
            // -----------------------------------
            $scope.addComment = function (content) {
                var comment = {
                    created: (new Date()).toISOString(),
                    user:    Auth.getName(),
                    comment: content
                };

                $scope.addItemToArrayField('comments', comment);
                $scope.comment = '';
                $scope.saveField('comments', $scope.item.comments);
            };

            $scope.show = function (content) {
                getDialogue({text: content}, 'text');
            };

            // ACTIONS
            // -----------------------------------
            $scope.download = function (id, fileName) {
                Progress.start();
                var url = Api.buildUrl('profiles/' + id + '/export', {'format': 'pdf'});

                Downloader.downloadFile(url, fileName + '.pdf').success(Progress.stop).error(Progress.error);
            };

            $scope.downloadFile = function (id, file) {
                Progress.start();
                var url = Api.buildUrl('documents/' + id + '/' + file.id);

                Downloader.downloadFile(url, file.name).success(Progress.stop).error(Progress.error);
            };

            $scope.uploadFile = function (id) {
                getDialogue({id: id}, 'upload').
                    then(function (files) {
                        _.forEach(files, function (file) {
                            $scope.addItemToArrayField('files', file);
                        });

                        $scope.saveField('files', $scope.item.files);
                    });
            };

            // UPDATE/SAVE DATA
            // -----------------------------------
            $scope.addItemToArrayField = function (field, value) {
                if (!_.isArray($scope.item[field])) {
                    $scope.item[field] = [];
                }

                $scope.item[field].push(value);
            };

            $scope.replaceItemInArrayField = function (field, value, index) {
                if (_.isArray($scope.item[field])) {
                    $scope.item[field][index] = value;
                }
            };

            $scope.removeItemFromArrayField = function (field, index) {
                $scope.item[field].splice(index, 1);

                $scope.saveField(field, $scope.item[field]);
            };

            $scope.saveField = function (field, value, update) {
                /**
                 * @todo Check whether the value has changed
                 */
                ProfileResource.saveField({id: id}, {field: field, value: value}, function (profile) {
                    if (update === true) {
                        profile = ProfileData.prepare(profile);
                        $scope.item[field] = profile[field];
                    }

                    ProfileResource.clearCache();
                }, function () {
                    Notify.error(Notify.SAVE_REQUEST_ERROR);
                });
            };

            $scope.save = function () {
                ProfileResource.save({id: $scope.item.id}, $scope.item, function (item) {
                    Notify.success(Notify.SUCCESS_SAVED);
                    ProfileResource.clearCache();
                }, function () {
                    Notify.error(Notify.SAVE_REQUEST_ERROR);
                });
            };
        }
    ]);
});