define(['app', 'underscore'], function (app, _) {
    'use strict';

    function ProfileSearchController($rootScope, Table, ProfileResource, ProfileProperties, Progress) {

        /**
         *
         * @param query
         */
        function init(query) {
            vm.table.init(
                ProfileResource.list,
                'id,name,position,description,score',
                true
            );

            if (vm.filters.length > 0) {
                _.forEach(vm.filters, function (filter) {
                    applyFilterToTable(filter);
                });
            }

            go(query);
        }

        /**
         *
         */
        function updateURL() {
            $rootScope.$state.transitionTo('app.search', {
                query:   vm.query,
                filters: JSON.stringify(vm.filters)
            }, {notify: false});
        }

        /**
         *
         * @param query
         */
        function go(query) {
            vm.query = query;
            updateURL();
            vm.table.search(query);
        }

        /**
         *
         * @param filter
         */
        function applyFilterToTable(filter) {
            var value = filter.value;
            if (filter.field === 'birthday') { // between search
                var from = new Date(), to = new Date();

                from.setFullYear(from.getFullYear() - (value.from || 0));
                to.setFullYear(to.getFullYear() - (value.to || 100));

                value = 'btw:' + to.toISOString() + '+' + from.toISOString();
            } else {
                if (filter.type === 'equals') {
                    value = '!' + value;
                } else if (filter.type === 'startsFrom') {
                    value = '/^' + value + '.*/i';
                } else if (filter.type === 'endsTo') {
                    value = '/.*' + value + '$/i';
                } else if (filter.type === 'contains') {
                    value = '/.*' + value + '.*/i';
                }
            }


            vm.table.addFilter(filter.field, value);
        }

        /**
         *
         * @param filter
         */
        function addFilter(filter) {
            applyFilterToTable(filter);

            vm.filters.push(_.clone(filter));
            vm.isFilterFormOpened = false;

            setDefaultFilter();
            updateURL();
        }

        /**
         *
         * @param filter
         */
        function removeFilter(filter, index) {
            vm.table.removeFilter(filter.field);
            vm.filters.splice(index, 1);
            updateURL();
        }

        /**
         *
         */
        function setDefaultFilter() {
            vm.filter = {'field': 'name.first', 'type': 'equals', 'value': ''};
        }

        /**
         *
         */
        function setDefaultFilterValue() {
            vm.filter.value = '';
        }

        // ProfileSearchController
        // -----------------------------------
        var vm = this;

        vm.RESULT_OK = 1;
        vm.RESULT_NOT_FOUND = -1;
        vm.RESULT_DEFAULT = 0;

        vm.result = vm.RESULT_DEFAULT;

        vm.isFilterFormOpened = false;

        vm.properties = ProfileProperties;
        vm.table = Table;
        vm.go = go;

        vm.query = $rootScope.$stateParams.query || '';

        vm.filters = JSON.parse($rootScope.$stateParams.filters) || [];
        vm.addFilter = addFilter;
        vm.removeFilter = removeFilter;
        vm.setDefaultFilterValue = setDefaultFilterValue;

        setDefaultFilter();

        init(vm.query);
    }

    ProfileSearchController.$inject = ['$rootScope', 'DataTable', 'ProfileResource', 'ProfileProperties', 'Progress'];
    app.controller('ProfileSearchController', ProfileSearchController);
});