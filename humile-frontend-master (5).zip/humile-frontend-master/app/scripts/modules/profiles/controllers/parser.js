define(['app'], function (app) {
    'use strict';

    function ProfileParserController(Progress, Upload, Api) {

        function removeFile(index) {
            vm.files.splice(index, 1);
        }

        function uploadFile(files) {
            Progress.start();

            var file = files[0];
            Upload.upload({
                url:  Api.buildUrl("profiles/import?format=application/pdf"),
                file: file
            }).success(function (data, status, headers, config) {
                console.log(data);

                Progress.stop();
            }).error(function () {
                Progress.error();
            });
        }

        // ProfileParserController
        // -----------------------------------
        var vm = this;

        vm.files = [];
        vm.uploadStage = true;

        vm.remove = removeFile;
        vm.upload = uploadFile;
    }

    ProfileParserController.$inject = ['Progress', 'Upload', 'Api'];
    app.controller('ProfileParserController', ProfileParserController);
});