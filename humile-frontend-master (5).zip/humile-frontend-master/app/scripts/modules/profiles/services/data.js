define(['app', 'underscore'], function (app, _) {
    'use strict';

    app.factory('ProfileData', [function () {
        return {
            prepare: function (profile) {
                if (profile) {
                    profile.birthday = profile.birthday ? new Date(profile.birthday) : null;

                    _.forEach(profile.experience, function (item) {
                        if (item) {
                            item.time.from = item.time.from ? new Date(item.time.from) : null;
                            item.time.to = item.time.to ? new Date(item.time.to) : null;
                        }
                    });

                    _.forEach(profile.education, function (item) {
                        if (item) {
                            item.time.from = item.time.from ? new Date(item.time.from) : null;
                            item.time.to = item.time.to ? new Date(item.time.to) : null;
                        }
                    });
                }

                return profile;
            }
        };
    }]);
});