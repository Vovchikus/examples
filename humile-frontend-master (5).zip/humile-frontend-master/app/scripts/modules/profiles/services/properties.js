define(['app'], function (app) {
    'use strict';

    app.factory('ProfileProperties', ['$filter', function ($filter) {
        var service = {};

        service.fields = {
            "name.first": "Имя",
            "name.last": "Фамилия",
            "name.middle": "Отчество",
            "position": "Должность",
            "gender": "Пол",
            "maritalStatus": "Семейное положение",
            "birthday": "Возраст",
            "city": "Город",
            "contact.value": "Один из контактов",
            "language.language": "Язык",
            "description":"О себе",
            "shortDescription":"Короткое описание",
            "skills":"Ключевые навыки",
            "comments.comment":"Комментарий",
            "experience.company.city":"Опыт работы > Город",
            "experience.company.name":"Опыт работы > Компания",
            "experience.position":"Опыт работы > Позиция",
            "experience.responsibilities":"Опыт работы > Должностные обязанности",
            "education.level":"Образование > Уровень",
            "education.institution.city":"Образование > Город",
            "education.institution.name":"Образование > Институт"
        };

        service.searchTypes = {
            "equals": "точно совпадает с",
            "startsFrom": "начинается с",
            "endsTo": "заканчивается на",
            "contains": "содержит"
        };

        service.contactTypes = [
            {"value": 'phone', "text": 'Телефон'},
            {"value": 'email', "text": 'E-mail'},
            {"value": 'skype', "text": 'Skype'}
        ];

        service.genders = [
            {"value": 'man', "text": 'Мужской'},
            {"value": 'woman', "text": 'Женский'},
            {"value": 'unknown', "text": 'Неизвестно'}
        ];

        service.maritalStatuses = [
            {"value": 'married', "text": {"woman": 'Замужем', "default": 'Женат'}},
            {"value": 'single', "text": {"woman": 'Не замужем', "default": 'Не женат'}},
            {"value": 'divorced', "text": {"woman": 'Разведена', "default": 'В разводе'}},
            {"value": 'widow', "text": {"woman": 'Вдова', "default": 'Вдовец'}},
            {"value": 'unknown', "text": {"woman": 'Неизвестно', "default": 'Неизвестно'}}
        ];

        service.languageLevel = [
            {
                "value": "basic",
                "text":  "базовые знания"
            },
            {
                "value": "can_read",
                "text":  "читаю профессиональную литературу"
            },
            {
                "value": "can_pass_interview",
                "text":  "могу проходить интервью"
            },
            {
                "value": "fluent",
                "text":  "свободно владею"
            },
            {
                "value": "native",
                "text":  "родной"
            }
        ];

        service.educationLevel = [
            {
                "value": "unknown",
                "text":  ""
            },
            {
                "value": "higher",
                "text":  "Высшее"
            },
            {
                "value": "bachelor",
                "text":  "Бакалавр"
            },
            {
                "value": "master",
                "text":  "Магистр"
            },
            {
                "value": "candidate",
                "text":  "Кандидат наук"
            },
            {
                "value": "doctor",
                "text":  "Доктор наук"
            },
            {
                "value": "unfinished_higher",
                "text":  "Неоконченное высшее"
            },
            {
                "value": "secondary",
                "text":  "Среднее"
            },
            {
                "value": "special_secondary",
                "text":  "Среднее специальное"
            },
            {
                "value": "training",
                "text":  "Повышение квалификации"
            },
            {
                "value": "courses",
                "text":  "Курсы/тренинги"
            }
        ];

        service.showGender = function (gender) {
            var selected = $filter('filter')(service.genders, {value: gender});
            return (gender && selected.length) ? selected[0].text : 'Пол';
        };

        service.showMaritalStatus = function (maritalStatus, gender) {
            var selected = $filter('filter')(service.maritalStatuses, {value: maritalStatus});
            return (maritalStatus && selected.length) ? (selected[0].text[gender] || selected[0].text.default) : 'Сем. положение';
        };

        service.showEducationalLevel = function (level) {
            var selected = $filter('filter')(service.educationLevel, {value: level});
            return selected[0].text;
        };

        service.showLanguageLevel = function (level) {
            var selected = $filter('filter')(service.languageLevel, {value: level});
            return selected[0].text;
        };

        service.showContactType = function (type) {
            var selected = $filter('filter')(service.contactTypes, {value: type});
            return selected[0].text;
        };

        return service;
    }]);
});