define([
    './controllers/file-upload',
    './controllers/history',
    './controllers/list',
    './controllers/search',
    './controllers/project-dialog',
    './controllers/parser',
    './controllers/view',
    './services/data',
    './services/properties'
], function () {});
