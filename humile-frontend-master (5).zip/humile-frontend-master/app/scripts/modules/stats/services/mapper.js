define(['app', 'underscore', 'moment'], function (app, _, moment) {
    'use strict';

    app.factory('StatsMapper', [function () {
        var service = {};

        /**
         *
         * @param stats
         * @param groupBy
         * @param type
         * @returns {Array}
         */
        service.map = function (stats, groupBy, type) {
            var data = [];
            _.forEach(stats, function (stat) {
                var item = {};

                if (groupBy === 'user') {
                    item.label = stat.user.name;
                } else if (groupBy === 'project') {
                    item.label = stat.project.name;
                } else if (groupBy === 'month') {
                    var month = moment().month(stat._id - 1);
                    item.label = month.format('MMMM');
                } else if (groupBy === 'week') {
                    var startDate = moment().isoWeek(stat._id).startOf('isoWeek');
                    var endDate = moment(startDate).endOf('isoWeek');

                    item.label = startDate.format('D MMM') + ' - ' + endDate.format('D MMM');
                } else if (groupBy === 'dayOfYear') {
                    var date = moment().dayOfYear(stat._id);

                    item.label = date.format('D MMM');
                } else {
                    item.label = stat._id;
                }

                if (type === 'states') {
                    _.forEach(stat.results, function (result) {
                        item[result.state] = result.count;
                    });
                } else {
                    _.forEach(stat.results, function (result) {
                        item[result.status] = result.count;
                    });
                }


                data.push(item);
            });

            return data;
        };

        /**
         *
         * @param stats
         */
        service.getOptions = function (stats) {
            var data = {
                ykeys: [],
                labels: [],
                barColors: []
            };

            _.forEach(stats, function (stat) {
                _.forEach(stat.results, function (result) {
                    data.ykeys.push(result.state);
                    data.labels.push(result.label);
                    data.barColors.push(result.color);
                });
            });

            return data;
        };

        /**
         *
         * @param groupBy
         * @returns {*}
         */
        service.getGroupingLabel = function (groupBy) {
            switch (groupBy) {
                case 'user':
                    return 'по имени пользователя';
                case 'project':
                    return 'по проекту';
                case 'year':
                    return 'по годам';
                case 'month':
                    return 'по месяцам';
                case 'week':
                    return 'по неделям';
                case 'dayOfYear':
                    return 'по дням';
            }
        };

        return service;
    }]);
});