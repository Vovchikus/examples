define(['app', 'underscore', 'moment'], function (app, _, moment) {
    'use strict';

    /**
     *
     * @param StatsResource
     * @param StatsMapper
     * @param Progress
     *
     * @constructor
     */
    function ProfileStatsController(StatsResource, StatsMapper, Progress) {
        /**
         * Initialization
         */
        function init() {
            Progress.start();
            StatsResource.profiles({
                'groupBy':   vm.groupBy,
                'startDate': moment(vm.from).format("YYYY-MM-DD H:mm"),
                'endDate':   moment(vm.to).format("YYYY-MM-DD H:mm")
            }, function (stats) {
                vm.data = StatsMapper.map(stats, vm.groupBy);

                vm.isLoaded = true;
                Progress.stop();
            }, function () {
                Progress.error();
            });
        }

        /**
         *
         * @returns {*}
         */
        function getGroupingLabel() {
            return StatsMapper.getGroupingLabel(vm.groupBy);
        }

        /**
         *
         * @param grouping
         */
        function setGrouping(grouping) {
            vm.groupBy = grouping;
            vm.isLoaded = false;

            vm.init();
        }

        // ProfileStatsController
        // -----------------------------------
        var vm = this;
        vm.init = init;

        vm.groupBy = 'dayOfYear';
        vm.getGroupingLabel = getGroupingLabel;
        vm.setGrouping = setGrouping;

        vm.data = [];
        vm.options = {
            xkey:      'label',
            ykeys:     ['created', 'changed', 'deleted'],
            labels:    ['Создано', 'Изменено', 'Удалено'],
            barColors: ['#7cb28a', '#fad732', '#f05050'],
            hideHover: 'auto',
            resize:    true,
            stacked:   false
        };
        vm.isLoaded = false;

        vm.datepicker = {
            opened: [false, false],
            open:   function ($event, index) {
                $event.preventDefault();
                $event.stopPropagation();

                vm.datepicker.opened[index] = true;
            }
        };

        vm.from = moment().subtract(7, 'days').hour(0).minutes(0).toDate();
        vm.to = moment().hour(23).minutes(59).toDate();

        vm.datesChanges = function () {
            vm.isLoaded = false;
            vm.init();
        };

        vm.init();

    }

    ProfileStatsController.$inject = ['StatsResource', 'StatsMapper', 'Progress'];
    app.controller('ProfileStatsController', ProfileStatsController);
});