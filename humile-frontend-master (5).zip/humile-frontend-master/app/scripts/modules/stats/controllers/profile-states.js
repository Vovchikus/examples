define(['app', 'underscore', 'moment'], function (app, _, moment) {
    'use strict';

    /**
     *
     * @param StatsResource
     * @param StatsMapper
     * @param Progress
     *
     * @constructor
     */
    function ProfileStatesStatsController(StatsResource, StatsMapper, Progress) {
        /**
         * Initialization
         */
        function init() {
            Progress.start();
            StatsResource.profileStates({
                    'groupBy':   vm.groupBy,
                    'startDate': moment(vm.from).format("YYYY-MM-DD H:mm"),
                    'endDate':   moment(vm.to).format("YYYY-MM-DD H:mm")
                },
                function (stats) {
                    vm.data = StatsMapper.map(stats, vm.groupBy, 'states');
                    vm.options = _.extend(vm.options, StatsMapper.getOptions(stats));

                    vm.isLoaded = true;
                    Progress.stop();
                }, function () {
                    Progress.error();
                });
        }

        /**
         *
         * @returns {*}
         */
        function getGroupingLabel() {
            return StatsMapper.getGroupingLabel(vm.groupBy);
        }

        /**
         *
         * @param grouping
         */
        function setGrouping(grouping) {
            vm.groupBy = grouping;
            vm.isLoaded = false;

            vm.init();
        }

        // ProfileStatesStatsController
        // -----------------------------------
        var vm = this;
        vm.init = init;

        vm.groupBy = 'dayOfYear';
        vm.getGroupingLabel = getGroupingLabel;
        vm.setGrouping = setGrouping;

        vm.data = [];
        vm.options = {
            xkey:      'label',
            ykeys:     [],
            labels:    [],
            barColors: [],
            hideHover: 'auto',
            resize:    true,
            stacked:   true
        };
        vm.isLoaded = false;

        vm.datepicker = {
            opened: [false, false],
            open:   function ($event, index) {
                $event.preventDefault();
                $event.stopPropagation();

                vm.datepicker.opened[index] = true;
            }
        };

        vm.from = moment().subtract(7, 'days').hour(0).minutes(0).toDate();
        vm.to = moment().hour(23).minutes(59).toDate();

        vm.datesChanges = function () {
            vm.isLoaded = false;
            vm.init();
        };

        vm.init();

    }

    ProfileStatesStatsController.$inject = ['StatsResource', 'StatsMapper', 'Progress'];
    app.controller('ProfileStatesStatsController', ProfileStatesStatsController);
});