define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param ProfileResource
     * @constructor
     */
    function ProjecstStatsController(ProfileResource) {
        /**
         * Initialization
         */
        function init() {
            console.log('Project stats');
        }

        // ProjecstStatsController
        // -----------------------------------
        var vm = this;
        vm.init = init;

        vm.init();
    }

    ProjecstStatsController.$inject = ['ProfileResource'];
    app.controller('ProjecstStatsController', ProjecstStatsController);
});