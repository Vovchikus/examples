define([
    './controllers/profile-states',
    './controllers/profiles',
    './controllers/projects',
    './services/mapper'
], function () {});
