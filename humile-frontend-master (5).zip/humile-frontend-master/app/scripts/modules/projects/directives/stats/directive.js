define(['app', 'underscore'], function (app, _) {
    'use strict';

    app.directive('projectStats', ['$compile', function ($compile) {
        return {
            restrict:    'E',
            templateUrl: '/scripts/modules/projects/directives/stats/view.html',
            scope:       {
                id: "="
            },
            controller:  'ProjectStatsController as stats'
        };
    }]);

    /**
     *
     * @param $scope
     * @param ProjectResource
     * @param Board
     * @constructor
     */
    function ProjectStatsController($scope, ProjectResource, Board) {
        function init(id) {
            ProjectResource.getStats({'id': id}, function (stats) {
                vm.data = stats;
                vm.donutOptions.colors = [];

                vm.donutData = stats.map(function (item) {
                    vm.donutOptions.colors.push(Board.getColor(item.state));
                    return {'label': Board.getLabel(item.state), value: item.count};
                });

                vm.isLoaded = true;
            });
        }

        // ProjectStatsController
        // -----------------------------------
        var vm = this;
        vm.init = init;
        vm.data = [];
        vm.isLoaded = false;

        vm.donutData = [];
        vm.donutOptions = {
            colors: [],
            resize: true
        };

        $scope.$watch('id', function (id) {
            if (!_.isUndefined(id) && vm.isLoaded === false) {
                vm.init(id);
            }
        }.bind(this));
    }

    ProjectStatsController.$inject = ['$scope', 'ProjectResource', 'Board'];
    app.controller('ProjectStatsController', ProjectStatsController);
});