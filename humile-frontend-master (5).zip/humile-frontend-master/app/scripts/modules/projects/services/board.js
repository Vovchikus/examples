define(['app', 'underscore'], function (app, _) {
    'use strict';

    app.factory('Board', [function () {
        var service = {};

        /**
         *
         * @type {Array}
         */
        service.states = [];

        /**
         *
         * @param state
         * @returns boolean
         */
        service.exists = function (state) {
            var result = _.findWhere(service.states, {name: state});

            return result !== undefined;
        };

        /**
         *
         * @param state
         * @returns {boolean}
         */
        service.nonExists = function (state) {
            return !service.exists(state);
        };

        /**
         *
         * @param state
         * @returns {*}
         */
        service.getStateDataByName = function (state) {
            return service.states.reduce(function (previous, current) {
                if (current.name === state) {
                    return current;
                }

                return previous;
            });
        };

        /**
         *
         * @param state
         * @returns {*}
         */
        service.getLabel = function (state) {
            return service.getStateDataByName(state).label;
        };

        /**
         *
         * @param state
         * @returns {*}
         */
        service.getColor = function (state) {
            return service.getStateDataByName(state).color;
        };

        /**
         *
         * @returns {*}
         */
        service.getLastState = function () {
            return _.reduce(
                service.states,
                function (previous, current) {
                    // Hmm... Clear your mind and look once more time at the code.
                    if (current.properties && current.properties.isLast === true) {
                        return current;
                    }

                    if (previous.properties && previous.properties.isLast === true) {
                        return previous;
                    }

                    return false;
                }
            );
        };

        /**
         *
         * @returns {Array|*}
         */
        service.getList = function () {
            return service.states;
        };

        /**
         *
         * @returns {{}}
         */
        service.getEmptyColumns = function () {
            var results = {};

            _.forEach(service.states, function (state) {
                results[state.name] = [];
            });

            return results;
        };

        /**
         * 4s length
         * @returns {string}
         */
        service.generateUniqueName = function () {
            return 'col_' + ("0000" + (Math.random() * Math.pow(36, 4) << 0).toString(36)).slice(-4);
        };

        /**
         *
         * @param state
         */
        service.addState = function (state) {
            service.states.push(state);
        };

        /**
         *
         * @param state
         * @param index
         */
        service.replaceState = function (state, index) {
            service.states[index] = state;
        };

        /**
         *
         * @param indexFrom
         * @param indexTo
         */
        service.swapStates = function (indexFrom, indexTo) {
            var tmp = service.states[indexTo];

            service.states[indexTo] = service.states[indexFrom];
            service.states[indexFrom] = tmp;
        };

        /**
         *
         * @param index
         */
        service.removeState = function (index) {
            service.states.splice(index, 1);
        };

        /**
         *
         * @param states
         */
        service.init = function (states) {
            service.states = states;
        };

        /**
         *
         * @returns {*[]}
         */
        service.getColors = function () {
            return [
                {'class': 'bg-success-light', 'label': 'Зеленый светлый', 'color': '#7fc17d'},
                {'class': 'bg-success', 'label': 'Зеленый', 'color': '#56ac6c'},
                {'class': 'bg-success-dark', 'label': 'Зеленый темный', 'color': '#48985d'},

                {'class': 'bg-info-light', 'label': 'Голубой светлый', 'color': '#51c6ea'},
                {'class': 'bg-info', 'label': 'Голубой', 'color': '#23b7e5'},
                {'class': 'bg-info-dark', 'label': 'Голубой темный', 'color': '#1797be'},

                {'class': 'bg-primary-light', 'label': 'Синий светлый', 'color': '#8bb8f1'},
                {'class': 'bg-primary', 'label': 'Синий', 'color': '#5d9cec'},
                {'class': 'bg-primary-dark', 'label': 'Синий темный', 'color': '#2f80e7'},

                {'class': 'bg-purple-light', 'label': 'Пурпурный светлый', 'color': '#9289ca'},
                {'class': 'bg-purple', 'label': 'Пурпурный', 'color': '#7266ba'},
                {'class': 'bg-purple-dark', 'label': 'Пурпурный темный', 'color': '#564aa3'},

                {'class': 'bg-yellow-light', 'label': 'Желтый светлый', 'color': '#fbe164'},
                {'class': 'bg-yellow', 'label': 'Желтый', 'color': '#fad732'},
                {'class': 'bg-yellow-dark', 'label': 'Желтый темный', 'color': '#f3ca06'},

                {'class': 'bg-warning-light', 'label': 'Оранжевый светлый', 'color': '#ffab5e'},
                {'class': 'bg-warning', 'label': 'Оранжевый', 'color': '#ff902b'},
                {'class': 'bg-warning-dark', 'label': 'Оранжевый темный', 'color': '#f77600'},

                {'class': 'bg-danger-light', 'label': 'Красный светлый', 'color': '#f47f7f'},
                {'class': 'bg-danger', 'label': 'Красный', 'color': '#f05050'},
                {'class': 'bg-danger-dark', 'label': 'Красный темный', 'color': '#ec2121'},


                {'class': 'bg-gray-light', 'label': 'Серый светлый', 'color': '#e4eaec'},
                {'class': 'bg-gray', 'label': 'Серый', 'color': '#dde6e9'},
                {'class': 'bg-gray-dark', 'label': 'Серый темный', 'color': '#3a3f51'}
            ];
        };

        return service;
    }]);
});