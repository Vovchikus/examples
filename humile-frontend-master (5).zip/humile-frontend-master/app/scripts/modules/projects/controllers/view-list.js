define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param $scope
     * @param ProjectResource
     * @param Progress
     * @constructor
     */
    function ProjectListViewController($rootScope, $scope, ProjectResource, Progress) {
        /**
         *
         * @param id
         */
        function loadProfiles(id) {
            var data = vm.board.getEmptyColumns();

            ProjectResource.profilesList({
                id:     id,
                fields: 'id,name,position,contacts,photo,salary,shortDescription,permissions,source',
                archived: false
            }, function (profiles) {
                _.forEach(profiles, function (profile) {
                    var state = vm.project.profiles[profile.id].state || 'raw';
                    data[state].push(profile);
                });

                vm.data = data;
                vm.profilesLoaded = true;
                Progress.stop();
            }, Progress.error);
        }

        /**
         *
         */
        function updateProject() {
            if ($scope.$parent) {
                vm.project = $scope.$parent.project.item;
                vm.board = $scope.$parent.project.board;
                vm.states = vm.board.getList();

                vm.id = $scope.$parent.project.id;
            }
        }

        $rootScope.$on('project:boardChanged', function (event) {
            if ($rootScope.$state.current.name === 'app.project.list') {
                updateProject();
                loadProfiles(vm.id);
            }
        });

        // ProjectArchiveViewController
        // -----------------------------------
        var vm = this;

        vm.profilesLoaded = false;
        vm.profiles = [];

        updateProject();
        loadProfiles(vm.id);
    }

    ProjectListViewController.$inject = ['$rootScope', '$scope', 'ProjectResource', 'Progress'];
    app.controller('ProjectListViewController', ProjectListViewController);
});