define(['app', 'underscore'], function (app, _) {
    'use strict';

    app.controller("ProjectListCtrl", [
        "$rootScope",
        "$scope",
        "DataTable",
        "ProjectResource",
        "UserResource",
        "ngDialog",
        "Notify",
        function ($rootScope, $scope, Table, ProjectResource, UserResource, Dialog, Notify) {
            $rootScope.checkAccess(['admin', 'hr']);

            $scope.table = Table;
            $scope.table.init(ProjectResource.list, 'id,name,profiles,profileIds,permissions,fullPermissions,favourite,states');

            var getDialogue = function (scope, template, options) {
                scope = _.extend($scope.$new(), scope);

                if (_.isUndefined(options)) {
                    options = {};
                }

                return Dialog.openConfirm({
                    template:         template,
                    preCloseCallback: 'preCloseCallbackOnScope',
                    className:        options.className || 'ngdialog-theme-default',
                    closeByDocument:  true,
                    closeByEscape:    true,
                    scope:            scope
                });
            };

            $scope.delete = function (item) {
                getDialogue({item: item}, 'template/deleteDialog')
                    .then(function (id) {
                        ProjectResource.delete({id: id}, function () {
                            Notify.success(Notify.SUCCESS_DELETED);
                            ProjectResource.clearCache();
                            $scope.table.reload();
                        });
                    });
            };

            $scope.create = function () {
                var item = {rawProfiles: [], fullPermissions: []};
                getDialogue(
                    {
                        isNew: true,
                        item:  item
                    },
                    '/scripts/modules/projects/views/dialogs/edit.html',
                    {className: 'ngdialog-theme-default ngdialog-wide'}
                ).then(
                    function (code) {
                        if (_.isObject(code)) {
                            Notify.success(Notify.SUCCESS);
                            $scope.table.reload();
                        } else if (code === 403) {
                            Notify.warning(Notify.ACCESS_DENIED);
                        } else {
                            Notify.error(Notify.ERROR);
                        }
                    }
                );
            };

            $scope.edit = function (item) {
                item.rawProfiles = [];

                getDialogue(
                    {
                        isNew: false,
                        item:  item
                    },
                    '/scripts/modules/projects/views/dialogs/edit.html',
                    {className: 'ngdialog-theme-default ngdialog-wide'}
                ).then(
                    function (code) {
                        if (_.isObject(code)) {
                            Notify.success(Notify.SUCCESS);
                            $scope.table.reload();
                        } else if (code === 403) {
                            Notify.warning(Notify.ACCESS_DENIED);
                        } else {
                            Notify.error(Notify.ERROR);
                        }
                    }
                );
            };

            $scope.share = function (item) {
                getDialogue(
                    {},
                    '/scripts/modules/projects/views/dialogs/share.html'
                ).then(
                    function (userId) {
                        ProjectResource.transfer(
                            {id: item.id, userId: userId},
                            function () {
                                Notify.success(Notify.SUCCESS);
                            },
                            function () {
                                Notify.error(Notify.ERROR);
                            }
                        );
                    }
                );
            };

            $scope.toggleFavourite = function (item) {
                item.favourite = !item.favourite;
                if (item.favourite) {
                    UserResource.addToFavourites({type: 'projects', value: item.id}, function () {
                        $rootScope.$emit('menuChanged', ['4-projects']);
                    });
                } else {
                    UserResource.removeFromFavourites({type: 'projects', value: item.id}, function () {
                        $rootScope.$emit('menuChanged', ['4-projects']);
                    });
                }

                ProjectResource.clearCache();
            };
        }
    ]);
});