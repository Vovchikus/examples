define(['app'], function (app) {
    'use strict';

    /**
     *
     * @param $scope
     * @constructor
     */
    function ProjectStatViewController($scope, Board) {
        // ProjectStatViewController
        // -----------------------------------
        var vm = this;
        vm.project = $scope.$parent.project.item;

        Board.init(vm.project.states);
    }

    ProjectStatViewController.$inject = ['$scope', 'Board'];
    app.controller('ProjectStatViewController', ProjectStatViewController);
});