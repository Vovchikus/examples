define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param $scope
     * @param ProjectResource
     * @param Board
     * @param Progress
     * @constructor
     */
    function ProjectHistoryViewController($scope, ProjectResource, Board, Progress) {
        /**
         *
         * @param id
         */
        function loadHistory(id) {
            ProjectResource.getHistory({id: id}, function (items) {
                vm.items = items;
                vm.isLoaded = true;
                Progress.stop();
            }, function () {
                Progress.error();
            });
        }

        // ProjectHistoryViewController
        // -----------------------------------
        var vm = this;
        vm.project = $scope.$parent.project.item;
        vm.id = $scope.$parent.project.id;

        vm.items = [];
        vm.isLoaded = false;

        Board.init(vm.project.states);
        vm.board = Board;

        Progress.start();
        loadHistory(vm.id);
    }

    ProjectHistoryViewController.$inject = ['$scope', 'ProjectResource', 'Board', 'Progress'];
    app.controller('ProjectHistoryViewController', ProjectHistoryViewController);
});