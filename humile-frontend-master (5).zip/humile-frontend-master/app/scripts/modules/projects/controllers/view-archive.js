define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param $scope
     * @param ProjectResource
     * @param Board
     * @param Progress
     * @constructor
     */
    function ProjectArchiveViewController($rootScope, $scope, ProjectResource, Board, Progress) {
        /**
         *
         * @param id
         */
        function loadProfiles(id) {
            vm.data = Board.getEmptyColumns();
            ProjectResource.profilesList({
                id:     id,
                fields: 'id,name,position,contacts,photo,salary,shortDescription,permissions',
                archived: true
            }, function (profiles) {
                _.forEach(profiles, function (profile) {
                    profile.state = vm.project.profiles[profile.id].state || 'raw';
                });

                vm.profiles = profiles;

                vm.profilesLoaded = true;
                Progress.stop();
            }, Progress.error);
        }

        $rootScope.$on('project:boardChanged', function (event) {
            loadProfiles(vm.id);
        });

        // ProjectArchiveViewController
        // -----------------------------------
        var vm = this;
        vm.project = $scope.$parent.project.item;
        vm.id = $scope.$parent.project.id;
        vm.profilesLoaded = false;
        vm.profiles = [];

        Board.init(vm.project.states);
        vm.board = Board;

        Progress.start();
        loadProfiles(vm.id);
    }

    ProjectArchiveViewController.$inject = ['$rootScope', '$scope', 'ProjectResource', 'Board', 'Progress'];
    app.controller('ProjectArchiveViewController', ProjectArchiveViewController);
});