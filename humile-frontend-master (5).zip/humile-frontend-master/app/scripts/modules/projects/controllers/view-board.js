define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $scope
     * @param $rootScope
     * @param ProjectResource
     * @param Progress
     * @constructor
     */
    function ProjectBoardViewController($scope, $rootScope, ProjectResource, Progress) {
        /**
         *
         * @param id
         */
        function loadProfiles(id) {
            var data = vm.board.getEmptyColumns();

            Progress.start();
            ProjectResource.profilesList({
                id:     id,
                fields: 'id,name,position,contacts,photo,salary,shortDescription,permissions'
            }, function (profiles) {
                _.forEach(profiles, function (profile) {
                    var state = vm.project.profiles[profile.id].state || 'raw';
                    data[state].push(profile);
                });

                vm.data = data;
                vm.profilesLoaded = true;
                Progress.stop();
            }, Progress.error);
        }

        /**
         *
         */
        function updateProject() {
            if ($scope.$parent) {
                vm.project = $scope.$parent.project.item;
                vm.board = $scope.$parent.project.board;
                vm.states = vm.board.getList();
                vm.lastState = vm.board.getLastState();

                vm.id = $scope.$parent.project.id;
            }
        }

        /**
         *
         * @param profile
         * @param index
         */
        function setLastState(profile, index) {
            if (vm.lastState !== false) {
                vm.setState(profile, vm.lastState.name, index);
            }
        }

        /**
         *
         * @param profile
         * @param state
         * @param index
         */
        function setState(profile, state, index) {
            if (index !== undefined) {
                vm.move(profile, state, index); // Move on board
            }

            vm.project.profiles[profile.id].state = state;
            ProjectResource.updateProfile(
                {'id': vm.id, 'profileId': profile.id, 'state': state},
                function () {
                    ProjectResource.clearCache();
                }
            );
        }

        /**
         *
         * @param profile
         * @param newState
         * @param index
         */
        function move(profile, newState, index) {
            var currentState = vm.project.profiles[profile.id].state;

            vm.data[currentState].splice(index, 1);
            vm.data[newState].push(profile);
        }

        /**
         *
         * @param event
         * @param index
         * @param profile
         * @param state
         * @returns {*}
         */
        function dropCallback(event, index, profile, state) {
            vm.setState(profile, state);

            return profile;
        }

        // Column management
        // -----------------------------------
        /**
         *
         */
        function saveState(onAfterSave) {
            ProjectResource.saveField(
                {'id': vm.id},
                {field: 'states', value: vm.board.getList()},
                function () {
                    if (typeof onAfterSave !== "undefined") {
                        onAfterSave();
                    }

                    vm.lastState = vm.board.getLastState();
                    ProjectResource.clearCache();
                }
            );
        }

        /**
         *
         */
        function addColumn() {
            var scope = {
                isNew:  true,
                item:   {
                    color: '#8bb8f1',
                    name:  vm.board.generateUniqueName()
                },
                colors: vm.board.getColors()
            };

            $rootScope.getDialog(
                scope,
                '/scripts/modules/projects/views/dialogs/editColumn.html'
            ).then(
                function (column) {
                    vm.board.addState(column);
                    saveState(function () {
                        vm.data[column.name] = [];
                    });
                }
            );
        }

        /**
         *
         * @param event
         * @param index
         * @param item
         * @returns {boolean}
         */
        function addColumnAndPushProfile(event, index, item) {
            /**
             *
             * @returns {number}
             */
            function findIndex() {
                var i = 0,
                    len = 0,
                    currentState = vm.project.profiles[item.id].state;
                for (i = 0, len = vm.data[currentState].length; i < len; i += 1) {
                    if (vm.data[currentState][i].id === item.id) {
                        return i;
                    }
                }

                return -1;
            }


            var scope = {
                isNew:  true,
                item:   {
                    color: '#8bb8f1',
                    name:  vm.board.generateUniqueName()
                },
                colors: vm.board.getColors()
            };

            $rootScope.getDialog(
                scope,
                '/scripts/modules/projects/views/dialogs/editColumn.html'
            ).then(
                function (column) {
                    vm.board.addState(column);
                    saveState(function () {
                        vm.data[column.name] = [];
                        setState(item, column.name, findIndex());
                    });
                }
            );

            return false;
        }

        /**
         *
         * @param column
         * @param index
         */
        function editColumn(column, index) {
            var scope = {
                isNew:  false,
                item:   _.clone(column), // Prevents update
                colors: vm.board.getColors()
            };

            $rootScope.getDialog(
                scope,
                '/scripts/modules/projects/views/dialogs/editColumn.html'
            ).then(
                function (column) {
                    vm.board.replaceState(column, index);
                    saveState();
                }
            );
        }

        /**
         *
         * @param column
         * @param index
         */
        function deleteColumn(column, index) {
            $rootScope.getDialog(
                {
                    item: column
                },
                'template/columnDeleteDialog'
            ).then(
                function () {
                    vm.board.removeState(index);
                    saveState(function () {
                        delete vm.data[column.name];
                    });
                }
            );
        }

        /**
         *
         * @param from
         * @param to
         */
        function moveColumn(from, to) {
            vm.board.swapStates(from, to);
            saveState();
        }

        $rootScope.$on('project:boardChanged', function (event) {
            if ($rootScope.$state.current.name === 'app.project.board') {
                updateProject();
                loadProfiles(vm.id);
            }
        });

        // ProjectBoardViewController
        // -----------------------------------
        var vm = this;

        vm.setState = setState;
        vm.setLastState = setLastState;
        vm.move = move;
        vm.dropCallback = dropCallback;

        vm.addColumn = addColumn;
        vm.addColumnAndPushProfile = addColumnAndPushProfile;
        vm.editColumn = editColumn;
        vm.deleteColumn = deleteColumn;
        vm.moveColumn = moveColumn;

        updateProject();
        loadProfiles(vm.id);
    }

    ProjectBoardViewController.$inject = ['$scope', '$rootScope', 'ProjectResource', 'Progress'];
    app.controller('ProjectBoardViewController', ProjectBoardViewController);
});