define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $scope
     * @param $rootScope
     * @param ProjectResource
     * @param ProfileResource
     * @param SuggestsResource
     * @param UserResource
     * @constructor
     */
    function ProjectEditDialogController($scope, $rootScope, ProjectResource, ProfileResource, SuggestsResource, UserResource) {
        /**
         *
         */
        function loadTemplates() {
            UserResource.listFavourites({type: 'templates'}, function (favourites) {
                vm.templates = _.union([{name: '-', states: []}], favourites.templates);
            });
        }

        /**
         *
         *
         */
        function setTemplate() {
            vm.item.states = vm.templates[vm.selectedTemplateIndex].states;
        }

        /**
         *
         * @param value
         * @returns {*}
         */
        function getProfiles(value) {
            return ProfileResource.list({
                filter: {'name.last': value},
                fields: 'id, name, permissions'
            }).$promise.then(
                function (response) {
                    return response.filter(function (profile) {
                        return profile.permissions.edit === true;
                    });
                }
            );
        }

        /**
         *
         * @param profile
         */
        function addProfile(profile) {
            vm.item.rawProfiles.push(profile);
        }

        /**
         *
         * @param index
         */
        function removeProfile(index) {
            vm.item.rawProfiles.splice(index, 1);
        }

        /**
         *
         * @param item
         * @returns {*}
         */
        function profileLabel(item) {
            if (_.isUndefined(item)) {
                return '';
            }

            return item.name.last + ' ' + (item.name.first || '');
        }

        /**
         *
         * @param value
         * @returns {*}
         */
        function getPermissionEntitySuggestions(value) {
            return SuggestsResource.companyOrUser({
                filter: {'name': value}
            }).$promise.then(
                function (response) {
                    return response;
                }
            );
        }

        /**
         *
         * @param entity
         * @param permission
         */
        function addPermission(entity, permission) {
            var defaultPermission = {
                view:   true,
                edit:   false,
                remove: false
            };

            permission = _.extend(defaultPermission, permission);

            permission.type = entity.type;
            permission.name = entity.name;
            permission.id = entity.id;

            vm.item.fullPermissions.push(permission);
        }

        /**
         *
         * @param index
         */
        function removePermission(index) {
            vm.item.fullPermissions.splice(index, 1);
        }

        /**
         *
         * @param item
         */
        function confirm(item) {
            if ((_.isArray(item.profiles) && item.profiles.length === 0) || vm.isNew) {
                item.profiles = {}; // dirty hack
            }

            var defaultState = 'raw';
            if (!vm.isNew) {
                defaultState = item.states[0].name;
            }

            _.forEach(item.rawProfiles, function (profile) {
                item.profiles[profile.id] = {
                    'id':    profile.id,
                    'state': defaultState
                };
            });

            item.permissions = item.fullPermissions;

            delete item.fullPermissions;
            delete item.rawProfiles;
            delete item.profileIds;

            ProjectResource.save({id: item.id}, {data: item}, function (updated) {
                ProjectResource.clearCache();
                $scope.$parent.confirm(updated);

                if (item.favourite) {
                    $rootScope.$emit('menuChanged', ['4-projects']);
                }
            }, function (e) {
                $scope.$parent.confirm(e.status);
            });
        }

        // ProjectEditDialogController
        // -----------------------------------
        var vm = this;

        vm.isNew = $scope.$parent.isNew;
        vm.item = $scope.$parent.item;

        vm.templates = [];
        vm.setTemplate = setTemplate;

        vm.getProfiles = getProfiles;
        vm.addProfile = addProfile;
        vm.removeProfile = removeProfile;
        vm.profileLabel = profileLabel;
        vm.getPermissionEntitySuggestions = getPermissionEntitySuggestions;
        vm.addPermission = addPermission;
        vm.removePermission = removePermission;

        vm.confirm = confirm;

        loadTemplates();
    }

    ProjectEditDialogController.$inject = ['$scope', '$rootScope', 'ProjectResource', 'ProfileResource', 'SuggestsResource', 'UserResource'];
    app.controller('ProjectEditDialogController', ProjectEditDialogController);
});