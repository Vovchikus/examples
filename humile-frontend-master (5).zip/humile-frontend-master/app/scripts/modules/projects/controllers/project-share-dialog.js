define(['app'], function (app) {
    'use strict';

    app.controller('ProjectShareDialogCtrl', [
        '$scope',
        'UserResource',
        'Notify',
        'Auth',
        function ($scope, UserResource, Notify, Auth) {
            $scope.do = function (login) {
                if (login === Auth.getLogin()) {
                    Notify.error('Вы пытаетесь передать проект самому себе!');
                } else {
                    UserResource.isExists({login: login}, function (user) {
                        if (user.exists === false) {
                            Notify.error('Пользователя с таким логином не существует!');
                        } else {
                            $scope.$parent.confirm(user.id);
                        }
                    }, function () {
                        Notify.error('Не удалось проверить имя пользователя.');
                    });
                }
            };
        }
    ]);
});