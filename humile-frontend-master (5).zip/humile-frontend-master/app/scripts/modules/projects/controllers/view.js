define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param $scope
     * @param ProjectResource
     * @param ProfileResource
     * @param UserResource
     * @param Board
     * @param Progress
     * @param Notify
     * @param Downloader
     * @param Api
     * @constructor
     */
    function ProjectViewController($rootScope, $scope, ProjectResource, ProfileResource, UserResource, Board, Progress, Notify, Downloader, Api) {
        /**
         *
         * @param item
         */
        function updateProjectData(item) {
            vm.item = item;
        }

        /**
         *
         * @param id
         */
        function loadProject(id) {
            Progress.start();
            ProjectResource.get({
                id:       id,
                'fields': 'id,name,profiles,profileIds,permissions,fullPermissions,favourite,states,created'
            }, function (item) {
                updateProjectData(item);
                Progress.stop();

                Board.init(item.states);
                vm.board = Board;
                vm.states = Board.getList();

                vm.isLoaded = true;
            }, function () {
                Progress.error();
                Notify.error(Notify.REQUEST_ERROR);
            });
        }

        /**
         *
         * @param id
         */
        function init(id) {
            $rootScope.checkAccess(['admin', 'hr']);
            loadProject(id);
        }

        /**
         *
         * @param item
         */
        function edit(item) {
            item.rawProfiles = [];

            $rootScope.getDialog(
                {
                    isNew: false,
                    item:  item
                },
                '/scripts/modules/projects/views/dialogs/edit.html',
                {className: 'ngdialog-theme-default ngdialog-wide'}
            ).then(
                function (code) {
                    if (_.isObject(code)) { // Hack
                        updateProjectData(code);

                        $rootScope.$emit('project:boardChanged');
                        Notify.success(Notify.SUCCESS);
                    } else if (code === 403) {
                        Notify.warning(Notify.ACCESS_DENIED);
                    } else {
                        Notify.error(Notify.ERROR);
                    }
                }
            );
        }

        /**
         *
         * @param item
         */
        function saveAsTemplate(item) {
            $rootScope.getDialog(
                {
                    name: item.name
                },
                '/scripts/modules/projects/views/dialogs/saveAsTemplate.html',
                {className: 'ngdialog-theme-default ngdialog-wide'}
            ).then(
                function (name) {
                    UserResource.addToFavourites({
                        type:  'templates',
                        value: {
                            name:   name,
                            states: item.states
                        }
                    }, function () {
                        Notify.success(Notify.SUCCESS);
                    }, function () {
                        Notify.error(Notify.ERROR);
                    });
                }
            );
        }

        /**
         *
         * @param item
         */
        function toggleFavourite(item) {
            item.favourite = !item.favourite;
            if (item.favourite) {
                UserResource.addToFavourites({type: 'projects', value: item.id}, function () {
                    $rootScope.$emit('menuChanged', ['4-projects']);
                });
            } else {
                UserResource.removeFromFavourites({type: 'projects', value: item.id}, function () {
                    $rootScope.$emit('menuChanged', ['4-projects']);
                });
            }

            ProjectResource.clearCache();
        }

        /**
         *
         * @param id
         * @param fileName
         */
        function download(id, fileName) {
            Progress.start();
            var url = Api.buildUrl('profiles/' + id + '/export', {'format': 'pdf'});

            Downloader.downloadFile(url, fileName + '.pdf').success(Progress.stop).error(Progress.error);
        }

        /**
         *
         * @param id
         */
        function selectProfile(id) {
            if (vm.selectedProfiles[id] === true) {
                vm.showActionsPanel = true;
            } else {
                var isNoOneSelected = _.reduce(vm.selectedProfiles, function (current, previous) {
                    return current || previous;
                });

                if (isNoOneSelected === false) {
                    vm.showActionsPanel = false;
                }
            }
        }

        /**
         *
         * @param selected
         */
        function selectAllProfiles(selected) {
            _.forEach(vm.item.profiles, function (profile) {
                vm.selectedProfiles[profile.id] = selected;
            });

            if (!selected) {
                vm.showActionsPanel = false;
            }
        }

        /**
         *
         * @param state
         */
        function selectAllInState(state, selected) {
            var isOneOrMoreSelected = false;

            if (selected === undefined) {
                selected = true;
            }

            _.forEach(vm.item.profiles, function (profile) {
                if (profile.state === state) {
                    vm.selectedProfiles[profile.id] = selected;
                    if (selected) {
                        isOneOrMoreSelected = true;
                    }
                }
            });

            if (isOneOrMoreSelected) {
                vm.showActionsPanel = true;
            } else {
                var isNoOneSelected = _.reduce(vm.selectedProfiles, function (current, previous) {
                    return current || previous;
                });

                if (isNoOneSelected === false) {
                    vm.showActionsPanel = false;
                }
            }
        }

        function getSelectedIds() {
            var ids = [];
            _.each(vm.selectedProfiles, function (value, id) {
                if (value === true) {
                    ids.push(id);
                }
            });

            return ids;
        }

        /**
         *
         * @param state
         */
        function setStateOnSelected(state) {
            Progress.start();
            ProjectResource.updateProfiles(
                {'id': vm.id, 'state': state, 'profiles': getSelectedIds()},
                function (project) {
                    Notify.success(Notify.SUCCESS);
                    updateProjectData(project);
                    ProjectResource.clearCache();

                    $rootScope.$emit('project:boardChanged');

                    vm.selectedProfiles = {};
                    vm.showActionsPanel = false;

                    Progress.stop();
                }, function () {
                    Progress.error();
                }
            );
        }

        /**
         *
         */
        function sendToEmail() {
            $rootScope.getDialog(
                {
                    'report': {
                        'email':   $rootScope.cache['default-email'],
                        'subject': $rootScope.cache['default-subject'] || 'Резюме с сайта humile.ru',
                        'content': $rootScope.cache['default-content'] || 'Здравствуйте! Во вложении резюме, выбранные вами для экспорта на сайте humile.ru.'
                    }
                },
                'template/sendToEmailDialogue'
            ).then(
                function (report) {
                    report = _.extend(report, {'ids': getSelectedIds()});

                    ProfileResource.report(report, function () {
                        $rootScope.cache['default-email'] = report.email;
                        $rootScope.cache['default-subject'] = report.subject;
                        $rootScope.cache['default-content'] = report.content;

                        Notify.success('Запрос успешно создан. Ожидайте письмо на <i>' + report.email + '</i>');
                    });
                }
            );
        }

        /**
         *
         */
        function archiveItems() {
            $rootScope.getDialog(
                {},
                'template/archiveProfiles'
            ).then(
                function () {
                    ProjectResource.archiveProfiles({
                        id:       vm.id,
                        profiles: getSelectedIds()
                    }, function (project) {
                        Notify.success(Notify.SUCCESS);
                        updateProjectData(project);
                        ProjectResource.clearCache();

                        vm.selectedProfiles = {};
                        vm.showActionsPanel = false;

                        $rootScope.$emit('project:boardChanged');
                    });
                }
            );
        }

        /**
         *
         */
        function restoreItems() {
            $rootScope.getDialog(
                {},
                'template/restoreProfiles'
            ).then(
                function () {
                    ProjectResource.restoreProfiles({
                        id:       vm.id,
                        profiles: getSelectedIds()
                    }, function (project) {
                        Notify.success(Notify.SUCCESS);
                        updateProjectData(project);
                        ProjectResource.clearCache();

                        vm.selectedProfiles = {};
                        vm.showActionsPanel = false;

                        $rootScope.$emit('project:boardChanged');
                    });
                }
            );
        }

        // ProjectViewController
        // -----------------------------------
        var vm = this;
        vm.id = $rootScope.$stateParams.id;
        vm.isLoaded = false;
        vm.init = init;

        vm.download = download;
        vm.edit = edit;
        vm.saveAsTemplate = saveAsTemplate;
        vm.toggleFavourite = toggleFavourite;

        vm.selectedProfiles = {};
        vm.showActionsPanel = false;
        vm.selectProfile = selectProfile;
        vm.selectAll = selectAllProfiles;
        vm.selectAllInState = selectAllInState;
        vm.setStateOnSelected = setStateOnSelected;
        vm.sendToEmail = sendToEmail;
        vm.archiveItems = archiveItems;
        vm.restoreItems = restoreItems;

        init(vm.id);

        vm.view = $rootScope.$state.current.name;

        $scope.$watch(angular.bind(this, function (view) {
            return this.view;
        }), function (view) {
            if (!_.isUndefined(view)) {
                $rootScope.$state.go(view, {'id': vm.id});
            }
        });
    }

    ProjectViewController.$inject = ['$rootScope', '$scope', 'ProjectResource', 'ProfileResource', 'UserResource', 'Board', 'Progress', 'Notify', 'Downloader', 'Api'];
    app.controller('ProjectViewController', ProjectViewController);
});