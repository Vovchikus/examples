define([
    './controllers/list',
    './controllers/project-edit-dialog',
    './controllers/project-share-dialog',
    './controllers/view',
    './controllers/view-archive',
    './controllers/view-board',
    './controllers/view-history',
    './controllers/view-list',
    './controllers/view-stat',
    './directives/stats/directive',
    './services/board'
], function () {});
