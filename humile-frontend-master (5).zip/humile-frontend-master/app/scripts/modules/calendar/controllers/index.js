define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param ProfileResource
     * @constructor
     */
    function CalendarController(ProfileResource) {
        /**
         *
         */
        function init() {
            ProfileResource.listAllInterviews(function (interviews) {
                vm.events = getCalendarEvents(interviews);
            });
        }

        /**
         *
         * @param interviews
         * @returns {Array}
         */
        function getCalendarEvents(interviews) {
            var events = [];
            _.forEach(interviews, function (interview) {
                var startDate = new Date(interview.date),
                    endDate = new Date(interview.date);
                endDate.setHours(endDate.getHours() + 1);

                var event = {
                    id:        interview.id,
                    profileId: interview.profileId,
                    title:     interview.profileName,
                    start:     startDate,
                    end:       endDate,
                    url:       '#/app/profile/' + interview.profileId
                };

                events.push(event);
            });

            vm.eventsLoaded = true;
            return events;
        }

        function eventChanged(event, delta) {
            var newDate = event.start.toISOString();
            ProfileResource.editInterviewDate({
                date:        newDate,
                interviewId: event.id,
                id:          event.profileId
            });
        }

        // CalendarController
        // -----------------------------------
        var vm = this;
        vm.init = init;
        vm.events = [];
        vm.eventDropCallback = eventChanged;
        vm.eventsLoaded = false;

        vm.init();
    }

    CalendarController.$inject = ['ProfileResource'];
    app.controller('CalendarController', CalendarController);
});