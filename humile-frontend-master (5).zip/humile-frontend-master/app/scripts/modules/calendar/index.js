define([
    './controllers/index'
], function () {});
