define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param Table
     * @param NewsResource
     * @param Dialog
     * @param Notify
     * @constructor
     */
    function NewsListController($rootScope, Table, NewsResource, Dialog, Notify) {

        function init() {
            $rootScope.checkAccess(['admin']);

            vm.table.init(
                NewsResource.list,
                'id,title,content,for,isActual'
            );
        }

        /**
         * @param scope
         * @param template
         * @param className
         * @returns {*}
         */
        function getDialogue(scope, template, className) {
            scope = _.extend($rootScope.$new(), scope);

            return Dialog.openConfirm({
                template:         template,
                preCloseCallback: 'preCloseCallbackOnScope',
                className:        className || 'ngdialog-theme-default',
                closeByDocument:  true,
                closeByEscape:    true,
                scope:            scope
            });
        }

        function createNews() {
            getDialogue({
                isNew: true,
                item: {
                    isActual: true,
                    for: ['admin', 'hr', 'customer']
                }
            }, 'template/newsEditDialog', 'ngdialog-theme-default ngdialog-wide')
                .then(function (data) {
                    NewsResource.save({data: data}, function () {
                        Notify.success(Notify.SUCCESS);
                        NewsResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        function editNews(item) {
            getDialogue({isNew: false, item: item}, 'template/newsEditDialog', 'ngdialog-theme-default ngdialog-wide')
                .then(function (data) {
                    NewsResource.save({id: item.id}, {data: data}, function () {
                        Notify.success(Notify.SUCCESS);
                        NewsResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        function deleteNews(item) {
            getDialogue({item: item}, 'template/newsDeleteDialog')
                .then(function (id) {
                    NewsResource.delete({id: id}, function () {
                        Notify.success(Notify.SUCCESS_DELETED);
                        NewsResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        // NewsListController
        // -----------------------------------
        var vm = this;
        vm.init = init;
        vm.table = Table;

        vm.create = createNews;
        vm.edit = editNews;
        vm.delete = deleteNews;

        vm.init();
    }

    NewsListController.$inject = ['$rootScope', 'DataTable', 'NewsResource', 'ngDialog', 'Notify'];
    app.controller('NewsListController', NewsListController);
});