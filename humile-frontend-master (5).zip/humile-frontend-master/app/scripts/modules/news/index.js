define([
    './controllers/list'
], function () {});
