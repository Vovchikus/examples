define([
    './calendar/index',
    './companies/index',
    './news/index',
    './projects/index',
    './profiles/index',
    './settings/index',
    './stats/index',
    './vacancies/index',
    './users/index'
], function () {});
