define(['app'], function (app) {
    'use strict';

    /**
     * @constructor
     */
    function CompanyViewController() {

        // CompanyViewController
        // -----------------------------------
        var vm = this;
    }

    CompanyViewController.$inject = [];
    app.controller('CompanyViewController', CompanyViewController);
});