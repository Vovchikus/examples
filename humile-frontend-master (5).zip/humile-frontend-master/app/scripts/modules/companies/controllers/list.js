define(['app', 'underscore'], function (app, _) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param Table
     * @param CompanyResource
     * @param Dialog
     * @param Notify
     * @constructor
     */
    function CompanyListController($rootScope, Table, CompanyResource, Dialog, Notify) {

        function init() {
            $rootScope.checkAccess(['admin']);

            vm.table.init(
                CompanyResource.list,
                'id, name'
            );
        }

        /**
         * @param scope
         * @param template
         * @returns {*}
         */
        function getDialogue(scope, template) {
            scope = _.extend($rootScope.$new(), scope);

            return Dialog.openConfirm({
                template:         template,
                preCloseCallback: 'preCloseCallbackOnScope',
                closeByDocument:  true,
                closeByEscape:    true,
                scope:            scope
            });
        }

        function createCompany() {
            getDialogue({isNew: true}, 'template/companyEditDialog')
                .then(function (data) {
                    CompanyResource.save({data: data}, function () {
                        Notify.success(Notify.SUCCESS);
                        CompanyResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        function editCompany(item) {
            getDialogue({isNew: false, item: item}, 'template/companyEditDialog')
                .then(function (data) {
                    CompanyResource.save({id: item.id}, {data: data}, function () {
                        Notify.success(Notify.SUCCESS);
                        CompanyResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        function deleteCompany(item) {
            getDialogue({item: item}, 'template/companyDeleteDialog')
                .then(function (id) {
                    CompanyResource.delete({id: id}, function () {
                        Notify.success(Notify.SUCCESS_DELETED);
                        CompanyResource.clearCache();
                        vm.table.reload();
                    });
                });
        }

        // CompanyListController
        // -----------------------------------
        var vm = this;
        vm.init = init;
        vm.table = Table;

        vm.create = createCompany;
        vm.edit = editCompany;
        vm.delete = deleteCompany;

        vm.init();
    }

    CompanyListController.$inject = ['$rootScope', 'DataTable', 'CompanyResource', 'ngDialog', 'Notify'];
    app.controller('CompanyListController', CompanyListController);
});