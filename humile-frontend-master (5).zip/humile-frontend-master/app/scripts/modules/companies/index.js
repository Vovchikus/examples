define([
    './controllers/list',
    './controllers/view'
], function () {});
