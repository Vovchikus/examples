define([
    './controllers/settings'
], function () {});
