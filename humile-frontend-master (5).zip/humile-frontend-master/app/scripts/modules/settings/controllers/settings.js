define(['app'], function (app) {
    'use strict';

    /**
     *
     * @param $rootScope
     * @param Auth
     * @param UserResource
     * @param Notify
     * @param Progress
     * @constructor
     */
    function SettingsController($rootScope, Auth, UserResource, Notify, Progress) {
        /**
         * On load
         */
        function init() {
            UserResource.getSettings(function (settings) {
                vm.settings = settings;
                vm.backup = settings.emailSettings.password;

                vm.isLoaded = true;
            });

            UserResource.get({id: Auth.getId()}, function (user) {
                vm.user = user;
            });
        }

        /**
         *
         * @param id
         * @param field
         * @param value
         */
        function saveField(id, field, value) {
            UserResource.saveField(
                {'id': id},
                {'field': field, 'value': value},
                function (user) {
                    Auth.setData(user);
                }
            );
        }

        /**
         *
         * @param settings
         */
        function saveSettings(settings) {
            if (vm.backup === settings.emailSettings.password) {
                settings.emailSettings.password = '';
            }

            Progress.start();
            UserResource.saveSettings(
                {'settings': settings},
                function (updatedSettings) {
                    vm.settings = updatedSettings;
                    vm.backup = updatedSettings.emailSettings.password;

                    Notify.success(Notify.SUCCESS_SAVED);
                    Progress.stop();
                },
                Progress.error
            );
        }

        /**
         *
         * @param emailSettings
         */
        function test(emailSettings) {
            Progress.start();
            UserResource.test(
                {'settings': emailSettings},
                function () {
                    Notify.success(Notify.SUCCESS);
                    Progress.stop();
                },
                Progress.error
            );
        }

        function preset(name) {
            switch (name) {
                case 'gmail':
                    vm.settings.emailSettings = {
                        'SMTPServer': 'smtp.gmail.com',
                        'port':       '465'
                    };
                    break;
                case 'yandex':
                    vm.settings.emailSettings = {
                        'SMTPServer': 'smtp.yandex.ru',
                        'port':       '465'
                    };
                    break;
                default:
                    break;
            }

        }

        /**
         *
         * @param type
         * @param settings
         */
        function enableIntegration(type, settings) {
            settings.enabled = true;
            vm.settings.integrations[type] = settings;

            saveSettings(vm.settings);
        }

        /**
         *
         * @param type
         */
        function disableIntegration(type) {
            vm.settings.integrations[type] = {
                enabled: false
            };

            saveSettings(vm.settings);

            $rootScope.$state.go('app.settings.default');
        }

        // SettingsController
        // -----------------------------------
        var vm = this;

        vm.isLoaded = false;

        vm.init = init;
        vm.settings = {};
        vm.backup = {};
        vm.user = {};

        vm.saveField = saveField;
        vm.saveSettings = saveSettings;
        vm.test = test;
        vm.preset = preset;

        vm.enableIntegration = enableIntegration;
        vm.disableIntegration = disableIntegration;

        vm.init();
    }

    SettingsController.$inject = ['$rootScope', 'Auth', 'UserResource', 'Notify', 'Progress'];
    app.controller('SettingsController', SettingsController);
});