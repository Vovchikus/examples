define([
    'angular',
    'jquery',
    'moment',
    'moment-ru',
    'app',
    'config/index',
    'resources/index',
    'controllers/index',
    'directives/index',
    'services/index',
    'modules/index'
], function (ng, $, moment) {
    'use strict';

    moment.locale('ru');

    $(window.document).ready(function () {
        ng.bootstrap(window.document, ['app']);
    });
});