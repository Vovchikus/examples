define([
    'angular',
    'raven',
    'angular-locale',
    'angular-animate',
    'angular-messages',
    'angular-bootstrap',
    'angular-cookies',
    'angular-resource',
    'angular-route',
    'angular-storage',
    'angular-sanitize',
    'angular-ui-router',
    'angular-ui-select',
    'angular-loading-bar',
    'angular-lazy-load',
    'angular-hotkeys',
    'angular-drag-n-drop',
    'angular-dialog',
    'angular-editable'
], function (ng, Raven) {
    'use strict';

    // INIT
    // -----------------------------------
    var app = ng.module('app', [
        'ngLocale',
        'ngRoute',
        'ngAnimate',
        'ngMessages',
        'ngStorage',
        'ngCookies',
        'ngSanitize',
        'ngResource',
        'ngDialog',

        'xeditable',
        'dndLists',
        'ui.bootstrap',
        'ui.router',
        'ui.select',
        'oc.lazyLoad',
        'cfp.loadingBar',
        'cfp.hotkeys'
    ]);

    // RUN
    // -----------------------------------
    app.run(['$rootScope', '$state', '$stateParams', '$window', 'editableOptions', 'SETTINGS',
        function ($rootScope, $state, $stateParams, $window, editableOptions, SETTINGS) {
            editableOptions.theme = 'bs3';

            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
            $rootScope.$storage = $window.localStorage;

            // GLOBALS
            // -----------------------------------
            $rootScope.app = SETTINGS.info;

            Raven.config('http://877f01a5427149d681569303649339d2@sentry.humile.ru:80/5', {
                release: SETTINGS.application.version
            }).install();
        }]);

    return app;
});