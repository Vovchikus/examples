define([
    './data/index',
    './elements/index',
    './events/index',
    './ui/index',
    './validation/index'
], function () {});
