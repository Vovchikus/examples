define(['app'], function (app) {
    'use strict';

    /**
     * Usage example:
     * <div sorting-controls="login"></div>
     *
     * @note Only when DataTable initialized in parent scope.
     */
    app.directive('sortingControls', [function () {
        return {
            restrict: 'EA',
            scope:    {field: "@sortingControls", controllerAs: "@controllerAs"},
            template: '<span class="glyphicon glyphicon-chevron-up" ng-click="asc()" ng-class="{active: isAscActive()}"></span>' +
                      '<span class="glyphicon glyphicon-chevron-down" ng-click="desc()" ng-class="{active: isDescActive()}"></span>',
            link:     function (scope, element, attrs) {
                var table = scope.$parent.table;

                if (scope.controllerAs !== undefined) { // "Controller as" hack
                    table = scope.$parent[scope.controllerAs].table;
                }

                element.addClass('sorting-controls');

                scope.asc = function () {
                    table.order(scope.field);
                };

                scope.desc = function () {
                    table.order('-' + scope.field);
                };

                scope.isAscActive = function () {
                    return table.row == scope.field;
                };

                scope.isDescActive = function () {
                    return table.row == '-' + scope.field;
                };
            }
        };
    }]);
});