define([
    'app',
    'jquery',
    'calendar'
], function (app, $) {
    'use strict';

    app.directive('calendar', Calendar);
    Calendar.$inject = ['$rootScope'];

    function Calendar() {
        /**
         *
         * @param scope
         * @param element
         */
        function link(scope, element) {
            if (!$.fn.fullCalendar) {
                return;
            }

            var calendar = element;

            initCalendar(
                calendar,
                scope.$parent.calendar.events,
                scope.$parent.calendar.eventDropCallback
            );
        }

        /**
         *
         * @type {{link: link, restrict: string}}
         */
        var directive = {
            link:     link,
            restrict: 'EA'
        };

        return directive;
    }

    /**
     * Invoke full calendar plugin and attach behavior
     */
    function initCalendar(calElement, events, dropCallback) {
        calElement.fullCalendar({
            lang:       'ru',
            header:     {
                left:   'prev,next today',
                center: 'title',
                right:  'month,agendaWeek,agendaDay'
            },
            buttonText: {
                today: 'сегодня',
                month: 'месяц',
                week:  'неделя',
                day:   'день'
            },
            editable:   true,
            eventDrop:  dropCallback,
            events:     events,
            eventColor:  '#5d9cec'
        });
    }
});