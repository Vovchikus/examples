define(['app'], function (app) {
    'use strict';

    /**
     * @usage <city-autocomplete is-required="false" ng-model="search.filter.value"></city-autocomplete>
     */
    app.directive('cityAutocomplete', ['$compile', function ($compile) {
        return {
            restrict:   'E',
            link:       function (scope, element, attrs) {
                var html =
                        '<input type="text" ' +
                        'ng-required="' + (attrs.isRequired || 'true') + '" name="city" ' +
                        'class="form-control" ' +
                        'ng-model="' + attrs.ngModel + '"' +
                        'typeahead="city.name as city for city in city.search($viewValue)"' +
                        'typeahead-template-url="/scripts/views/templates/city-autocomplete.html"' +
                        'typeahead-wait-ms="200"' +
                        'typeahead-min-length="2"' +
                        'typeahead-loading="loadingCities"' +
                        '>',
                    el = angular.element(html),
                    compiled = $compile(el);

                element.replaceWith(el);
                compiled(scope);
            },
            controller: 'CityAutocompleteController as city'
        };
    }]);

    /**
     *
     * @param SuggestsResource
     * @constructor
     */
    function CityAutocompleteController(SuggestsResource) {

        /**
         *
         * @param name
         * @returns {*}
         */
        function search(name) {
            return SuggestsResource.city({
                name:  name,
                limit: 10
            }).$promise.then(
                function (response) {
                    return response;
                }
            );
        }

        // CityAutocompleteController
        // -----------------------------------
        var vm = this;

        vm.search = search;
    }

    CityAutocompleteController.$inject = ['SuggestsResource'];
    app.controller('CityAutocompleteController', CityAutocompleteController);
});