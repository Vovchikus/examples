define(['app'], function (app) {
    'use strict';

    /**
     * @usage  <language-autocomplete is-required="false" ng-model="search.filter.value"></language-autocomplete>
     */
    app.directive('languageAutocomplete', ['$compile', function ($compile) {
        return {
            restrict:   'E',
            link:       function (scope, element, attrs) {
                var html =
                        '<input type="text" ' +
                        'ng-required="' + (attrs.isRequired || 'true') + '" name="language" ' +
                        'class="form-control" ' +
                        'ng-model="' + attrs.ngModel + '"' +
                        'typeahead="language.name as language.name for language in language.search($viewValue)"' +
                        'typeahead-wait-ms="200"' +
                        'typeahead-min-length="2"' +
                        'typeahead-loading="loadingLanguages"' +
                        '>',
                    el = angular.element(html),
                    compiled = $compile(el);

                element.replaceWith(el);
                compiled(scope);
            },
            controller: 'LanguageAutocompleteController as language'
        };
    }]);

    /**
     *
     * @param SuggestsResource
     * @constructor
     */
    function LanguageAutocompleteController(SuggestsResource) {

        /**
         *
         * @param name
         * @returns {*}
         */
        function search(name) {
            return SuggestsResource.language({
                name:  name,
                limit: 10
            }).$promise.then(
                function (response) {
                    return response;
                }
            );
        }

        // LanguageAutocompleteController
        // -----------------------------------
        var vm = this;

        vm.search = search;
    }

    LanguageAutocompleteController.$inject = ['SuggestsResource'];
    app.controller('LanguageAutocompleteController', LanguageAutocompleteController);
});