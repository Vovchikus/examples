define([
    './calendar',
    './city-autocomplete',
    './language-autocomplete',
    './sorting-controls'
], function () {});
