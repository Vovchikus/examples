define(['app'], function (app) {
    'use strict';

    /**
     * <input type="text" name="field" ng-model="field" required compare-to="anotherField" />
     * ... <div ng-message="compareTo">Must match the previous entry</div> ...
     *
     * @returns {{require: string, scope: {otherModelValue: string}, link: Function}}
     */
    var compareTo = function () {
        return {
            require: 'ngModel',
            scope:   {
                otherModelValue: '=compareTo'
            },
            link:    function (scope, element, attributes, ngModel) {

                ngModel.$validators.compareTo = function (modelValue) {
                    return modelValue == scope.otherModelValue;
                };

                scope.$watch('otherModelValue', function () {
                    ngModel.$validate();
                });
            }
        };
    };

    app.directive('compareTo', compareTo);
});