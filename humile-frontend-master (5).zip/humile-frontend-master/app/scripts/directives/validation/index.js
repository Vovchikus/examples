define([
    './compare'
], function () {});
