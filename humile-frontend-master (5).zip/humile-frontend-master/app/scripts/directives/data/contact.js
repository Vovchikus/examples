define(['app'], function (app) {
    'use strict';

    app.filter('contactTypeLabel', [function () {
        return function (input) {
            var result = input;

            switch (input) {
            case 'phone':
                result = 'Телефон';
                break;
            case 'email':
                result = 'E-mail';
                break;
            case 'skype':
                result = 'Skype';
                break;
            default:
                break;
            }

            return result;
        };
    }]);

    app.filter('contactFormat', [function () {
        return function (input, type) {
            var result = input, normalizePhone = function (phone) {
                phone = phone.replace(/[^\d]/g, "");
                if (phone.length === 10) {
                    return phone.replace(/(\d{3})(\d{3})(\d{2})(\d{2})/, "+7 ($1) $2-$3-$4");
                }

                return phone;
            };

            switch (type) {
            case 'phone':
                result = normalizePhone(input);
                break;
            default:
                break;
            }

            return result;
        };
    }]);
});