define(['app', 'moment', 'underscore'], function (app, moment, _) {
    'use strict';

    app.filter('formatDate', [function () {
        return function (input, modifier) {
            var result, format = 'DD MMMM, HH:mm';

            if (modifier === 'date') {
                format = 'DD MMMM YYYY';
            } else if (modifier === 'month') {
                format = 'MMMM YYYY';
            }

            if (_.isUndefined(input) || _.isNull(input) || input === 'null') {
                result = '-';
            } else {
                var date = moment(input);
                result = date.format(format);
            }

            return result;
        };
    }]);

    app.filter('age', [function () {
        return function (input) {
            var date = moment(input);
            return date.month(0).from(moment().month(0)).replace(/назад/g, ''); // Moment hack
        };
    }]);

    app.filter('fromNow', [function () {
        return function (input) {
            return moment(input).fromNow();
        };
    }]);


    /**
     * Usage example
     * <span experience-range="experience"></span>
     */
    app.directive('experienceRange', [function () {
        return {
            restrict: 'A',
            scope:    {
                experience: "=experienceRange"
            },
            link:     function (scope, element, attrs) {
                var repaint = function (experience) {
                    var start = moment(experience.time.from),
                        end = moment(experience.time.to);

                    if (experience.time.isCurrent) {
                        end = moment();
                    }

                    var range = end.diff(start, 'milliseconds');
                    element.text(moment.duration(range).humanize());
                };

                scope.$watch('experience', function (newValue, oldValue) {
                    if (!_.isUndefined(newValue) && newValue !== oldValue) {
                        repaint(newValue);
                    }
                }, true);

                repaint(scope.experience);
            }
        };
    }]);

    /**
     * Usage example
     * <span summary-experience="item.experience"></span>
     */
    app.directive('summaryExperience', [function () {
        return {
            restrict: 'A',
            scope:    {
                experience: "=summaryExperience"
            },
            link:     function (scope, element, attrs) {
                var repaint = function (experience) {
                    var summary = 0;

                    _.forEach(experience, function (item) {
                        var start = moment(item.time.from),
                            end = moment(item.time.to);

                        if (item.time.isCurrent) {
                            end = moment();
                        }

                        summary += end.diff(start, 'milliseconds');
                    });

                    var text = moment.duration(summary).humanize();

                    element.text(text.replace(/несколько секунд/g, '-'));
                };

                scope.$watch('experience', function (newValue, oldValue) {
                    if (!_.isUndefined(newValue) && newValue !== oldValue) {
                        repaint(newValue);
                    }
                }, true);

                repaint(scope.experience);
            }
        };
    }]);

    /**
     * DatePicker popup viewValue possible fix
     */
    app.directive('datepickerPopup', function () {
        return {
            restrict: 'EAC',
            require:  'ngModel',
            link:     function (scope, element, attr, controller) {
                controller.$formatters.shift();
            }
        };
    });
});