define([
    './contact',
    './date',
    './indicators',
    './text'
], function () {});
