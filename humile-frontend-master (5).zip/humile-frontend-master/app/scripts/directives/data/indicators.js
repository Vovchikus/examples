define(['app', 'moment', 'underscore'], function (app, moment, _) {
    'use strict';

    /**
     * Usage example
     * <span status code="{{ statusCode }}"></span>
     */
    app.directive('status', [function () {
        return {
            restrict: 'A',
            scope:    {
                code: "="
            },
            link:     function (scope, element, attrs) {
                var repaint = function (newValue) {
                    var text = '',
                        labelClass = '';
                    element.removeClass();
                    element.addClass('label');
                    switch (newValue) {
                        case -1:
                            labelClass = 'label-danger';
                            text = 'Заблокирован';
                            break;
                        case 0:
                            labelClass = 'label-default';
                            text = 'Неактивен';
                            break;
                        default:
                            labelClass = 'label-success';
                            text = 'Активен';
                            break;
                    }

                    element.text(text);
                    element.addClass(labelClass);
                };

                scope.$watch('code', function (newValue, oldValue) {
                    if (!_.isUndefined(newValue) && newValue !== oldValue) {
                        repaint(newValue);
                    }
                }, true);

                repaint(scope.code);
            }
        };
    }]);

    /**
     * Usage example
     * <span vacancy-status="{{ value }}"></span>
     */
    app.directive("vacancyStatus", [function () {
        return function (scope, element, attrs) {
            var value = attrs.vacancyStatus,
                text = '',
                labelClass = '';

            switch (value) {
            case 'draft':
                labelClass = 'label-default';
                text = 'Черновик';
                break;
            case 'opened':
                labelClass = 'label-primary';
                text = 'Открыта';
                break;
            case 'accepted':
                labelClass = 'label-info';
                text = 'Принята в работу';
                break;
            case 'waiting':
                labelClass = 'label-danger';
                text = 'Ожидает ответа';
                break;
            case 'in_progress':
                labelClass = 'label-warning';
                text = 'Выполняется';
                break;
            case 'ready':
                labelClass = 'label-success';
                text = 'Исполнена';
                break;
            case 'closed':
                labelClass = 'label-inverse';
                text = 'Закрыта';
                break;
            }

            element.text(text);
            element.addClass('label');
            element.addClass(labelClass);
        };
    }]);


    /**
     * Usage example
     * <span interview-status="{{ value }}"></span>
     */
    app.directive("interviewStatus", [function () {
        return function (scope, element, attrs) {
            var value = attrs.interviewStatus,
                text = '',
                labelClass = '';

            switch (value) {
            case 'new':
                labelClass = 'label-default';
                text = 'Актуально';
                break;
            case 'successfully':
                labelClass = 'label-success';
                text = 'Успешо';
                break;
            case 'unsuccessfully':
                labelClass = 'label-danger';
                text = 'Неудачно';
                break;
            case 'cancelled':
                labelClass = 'label-warning';
                text = 'Отменено';
                break;
            }

            element.text(text);
            element.addClass('label');
            element.addClass(labelClass);
        };
    }]);

    /**
     * Usage example
     * <span boolean="{{ value }}"></span>
     */
    app.directive("boolean", [function () {
        return function (scope, element, attrs) {
            var value = attrs.boolean,
                text = '',
                labelClass = '';

            if (value === "true" || value === true) {
                labelClass = 'label-success';

                if (attrs.booleanType === "on/off") {
                    text = 'Включено';
                } else {
                    text = 'Да';
                }
            } else {
                labelClass = 'label-danger';
                if (attrs.booleanType === "on/off") {
                    text = 'Выключено';
                } else {
                    text = 'Нет';
                }
            }

            element.text(text);
            element.addClass('label');
            element.addClass(labelClass);
        };
    }]);
});