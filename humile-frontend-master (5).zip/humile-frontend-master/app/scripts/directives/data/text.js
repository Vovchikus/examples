define(['app'], function (app) {
    'use strict';

    app.filter('truncate', function () {
        return function (text, length, end) {
            if (isNaN(length)) {
                length = 25;
            }

            if (text === null || text === undefined) {
                text = '';
            }

            if (end === undefined) {
                end = '...';
            }

            if (text.length <= length || text.length - end.length <= length) {
                return text;
            }

            return String(text).substring(0, length - end.length) + end;
        };
    });

});