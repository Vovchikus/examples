define([
    'app',
    '../../../vendor/raphael/raphael-min',
    '../../../vendor/morrisjs/morris.min'
], function (app) {
    'use strict';

    function morrisChart(type) {
        return function () {
            return {
                restrict: 'EA',
                scope:    {
                    morrisData:    '=',
                    morrisOptions: '='
                },
                link:     function (scope, elem, attrs) {
                    scope.$watch("morrisData", function (newVal, oldVal) {
                        if (newVal) {
                            scope.morrisInstance.setData(newVal);
                            scope.morrisInstance.redraw();
                        }
                    }, true);
                    scope.morrisOptions.element = elem;
                    if (scope.morrisData)
                        scope.morrisOptions.data = scope.morrisData;
                    scope.morrisInstance = new Morris[type](scope.morrisOptions);
                }
            }
        }
    }

    app.directive('morrisBar', morrisChart('Bar'));
    app.directive('morrisDonut', morrisChart('Donut'));
    app.directive('morrisLine', morrisChart('Line'));
    app.directive('morrisArea', morrisChart('Area'));

});
