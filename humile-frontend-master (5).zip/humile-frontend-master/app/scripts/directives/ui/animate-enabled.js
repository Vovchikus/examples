define([
    'app'
], function (app) {
    'use strict';

    app.directive('animateEnabled', ['$animate', function ($animate) {
        return {
            link: function (scope, element, attrs) {
                scope.$watch(function () {
                    return scope.$eval(attrs.animateEnabled, scope);
                }, function (newValue) {
                    $animate.enabled(!!newValue, element);
                });
            }
        };
    }]);

});
