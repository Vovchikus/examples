define([
    'app'
], function (app) {
    'use strict';

    app.directive('uiSlider', [function () {
        return {
            restrict:   'A',
            controller: ['$scope', '$element', function ($scope, $element) {
                var $elem = $($element);
                if ($.fn.slider)
                    $elem.slider();
            }]
        };
    }]);
});

