define([
    'app'
], function (app) {
    'use strict';

    app.directive('toggleFullscreen', [function () {
        return {
            restrict: 'A',
            link:     function (scope, element, attrs) {

                element.on('click', function (e) {
                    e.preventDefault();

                    if (screenfull.enabled) {
                        screenfull.toggle();
                        if (screenfull.isFullscreen)
                            $(this).children('em').removeClass('fa-expand').addClass('fa-compress');
                        else
                            $(this).children('em').removeClass('fa-compress').addClass('fa-expand');

                    } else {
                        $.error('Fullscreen not enabled');
                    }

                });
            }
        };

    }]);

});


