define([
    'app'
], function (app) {
    'use strict';

    app.directive('checkAll', [function () {
        return {
            restrict:   'A',
            controller: ['$scope', '$element', function ($scope, $element) {

                $element.on('change', function () {
                    var $this = $(this),
                        index = $this.index() + 1,
                        checkbox = $this.find('input[type="checkbox"]'),
                        table = $this.parents('table');
                    table.find('tbody > tr > td:nth-child(' + index + ') input[type="checkbox"]')
                        .prop('checked', checkbox[0].checked);

                });
            }]
        };

    }]);

});
