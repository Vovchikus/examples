define([
    'app'
], function (app) {
    'use strict';

    app.directive("fileReader", ["Notify", function (Notify) {
        return {
            scope: {
                fileReader: "="
            },
            link:  function (scope, element, attributes) {
                var MAX_UPLOAD_SIZE = 500000; // 200 KB

                element.bind("change", function (changeEvent) {
                    scope.fileReader = [];

                    var filesCount = changeEvent.target.files.length,
                        isOver = function (count) {
                            if (count === 0) {
                                scope.$emit('fileReader:loaded', scope.fileReader);
                            }
                        };
                    _.forEach(changeEvent.target.files, function (file) {
                        if (file.size > MAX_UPLOAD_SIZE) {
                            Notify.error("Превышен максимальный размер файла: 200Кб!");
                        } else {
                            var reader = new FileReader();
                            reader.onload = function (loadEvent) {
                                scope.$apply(function () {
                                    scope.fileReader.push(loadEvent.target.result);
                                    filesCount--;
                                    isOver(filesCount);
                                });
                            };

                            reader.readAsDataURL(file);
                        }
                    });
                });
            }
        }
    }]);

    /**
     * Usage example:
     * <input accept="text/csv" type="file" class="btn-info"
     *     title="Выбрать файл"
     *     required="true"
     *     file-model="file"
     * />
     *
     * var data = new FormData();
     * data.append('file', $scope.file);
     * $http.post(<url>, data, {
     *              transformRequest: angular.identity,
     *              headers:          {'Content-Type': undefined}
     *          };
     */
    app.directive('fileModel', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link:     function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }]);

});
