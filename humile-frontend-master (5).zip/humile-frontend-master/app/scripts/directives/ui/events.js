define(['app'], function (directives) {
    'use strict';

    /**
     * Set focus to new item
     */
    directives.directive('ngFocused', [function () {
        return function (scope, element, attrs) {
            element.focus();
        };
    }]);
});

