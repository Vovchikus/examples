define([
    'app'
], function (app) {
    'use strict';

    app.directive('sparkline', ['$timeout', '$window', function ($timeout, $window) {
        return {
            restrict:   'EA',
            controller: ['$scope', '$element', function ($scope, $element) {
                var runSL = function () {
                    initSparLine($element);
                };

                $timeout(runSL);
            }]
        };

        function initSparLine($element) {
            var options = $element.data();

            options.type = options.type || 'bar';
            options.disableHiddenCheck = true;

            $element.sparkline('html', options);

            if (options.resize) {
                $(window).resize(function () {
                    $element.sparkline('html', options);
                });
            }
        }
    }]);
});

