define([
    'app'
], function (app) {
    'use strict';

    // Authorization interceptor
    // -----------------------------------
    app.factory('authHttpResponseInterceptor', ['$q', 'Auth', 'Api', 'SETTINGS', function ($q, Auth, Api, SETTINGS) {
        return {
            request: function (config) {
                config.headers.Authorization = Auth.getToken();

                if (config.url.search(/^template/ig) === -1 &&
                    config.url.search(/^bootstrap/ig) === -1)
                { // angular-bootstrap templates hack
                    config.url = Api.addQueryParams(config.url, {'v': SETTINGS.application.version});
                }

                return config || $q.when(config);
            },

            response: function (response) {
                return response || $q.when(response);
            },

            responseError: function (rejection) {
                if (rejection.status === 401) {
                    Auth.logout();
                }
                return $q.reject(rejection);
            }
        };
    }]);

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push('authHttpResponseInterceptor');
    }]).config(['cfpLoadingBarProvider', function (cfpLoadingBarProvider) {
        cfpLoadingBarProvider.includeBar = true;
        cfpLoadingBarProvider.includeSpinner = false;
        cfpLoadingBarProvider.latencyThreshold = 500;
        cfpLoadingBarProvider.parentSelector = '.wrapper > section';
    }]).config(['hotkeysProvider', function (hotkeysProvider) {
        hotkeysProvider.includeCheatSheet = false;
    }]);

    // Bootstrap pagination config
    // -----------------------------------
    app.constant("paginationConfig", {
        maxSize:        4,
        itemsPerPage:   10,
        boundaryLinks:  false,
        directionLinks: true,
        firstText:      '<<',
        previousText:   "<",
        nextText:       ">",
        lastText:       ">>",
        rotate:         false
    });
});