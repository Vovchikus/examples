define([
    './constants',
    './config',
    './routes'
], function () {});
