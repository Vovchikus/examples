define([
    'app'
], function (app) {
    'use strict';

    app.config([
        '$stateProvider',
        '$urlRouterProvider',
        '$ocLazyLoadProvider',
        'MODULES',
        function ($stateProvider, $urlRouterProvider, $ocLazyLoadProvider, MODULES) {
            var basePath = function (uri) {
                return '/scripts/views/' + uri;
            }, modulesPath = function (module, uri) {
                return '/scripts/modules/' + module + '/views/' + uri;
            }, resolveFor = function () {
                var args = arguments;
                return {
                    deps: ['$ocLazyLoad', '$q', function ($loader, $q) {
                        var promise = $q.when(1);
                        for (var i = 0, len = args.length; i < len; i++) {
                            promise = andThen(args[i]);
                        }
                        return promise;

                        function andThen(arg) {
                            if (typeof arg == 'function')
                                return promise.then(arg);
                            else
                                return promise.then(function () {
                                    var whatToLoad = getRequired(arg);
                                    if (!whatToLoad) return $.error('Route resolve: Bad resource name [' + arg + ']');
                                    return $loader.load(whatToLoad);
                                });
                        }

                        function getRequired(name) {
                            if (MODULES.modules)
                                for (var m in MODULES.modules)
                                    if (MODULES.modules[m].name && MODULES.modules[m].name === name)
                                        return MODULES.modules[m];
                            return MODULES.scripts && MODULES.scripts[name];
                        }

                    }]
                };
            };

            // Loader config
            // -----------------------------------
            $ocLazyLoadProvider.config({
                debug:   false,
                events:  false,
                modules: MODULES.modules
            });

            // Application Routes
            // -----------------------------------
            $urlRouterProvider.otherwise('/app/dashboard');

            $stateProvider
                .state('app', {
                    url:         '/app',
                    abstract:    true,
                    templateUrl: basePath('app.html'),
                    controller:  'AppController',
                    resolve:     resolveFor('fastclick', 'modernizr', 'screenfull', 'animo', 'sparklines', 'slimscroll', 'whirl')
                })
                .state('app.dashboard', {
                    url:         '/dashboard',
                    title:       'Главная',
                    templateUrl: basePath('dashboard.html')
                })

                // Vacancies management
                // -----------------------------------
                .state('app.vacancies', {
                    url:         '/vacancies',
                    templateUrl: modulesPath('vacancies', 'list.html'),
                    controller:  'VacancyListController as vacancies'
                })
                .state('app.vacancy', {
                    url:         '/vacancy/{id}',
                    templateUrl: modulesPath('vacancies', 'view.html'),
                    controller:  'VacancyViewController as vacancy'
                })
                .state('app.search-vacancies', {
                    url:         '/search-vacancies/',
                    templateUrl: modulesPath('vacancies', 'search.html'),
                    controller:  'SearchVacanciesController as vacancies'
                })

                // User management
                // -----------------------------------
                .state('app.users', {
                    url:         '/users',
                    templateUrl: modulesPath('users', 'list.html')
                })
                .state('app.user', {
                    url:         '/user/{id}',
                    params:      {id: {value: null}},
                    templateUrl: modulesPath('users', 'view.html')
                })

                // Company management
                // -----------------------------------
                .state('app.companies', {
                    url:         '/companies',
                    templateUrl: modulesPath('companies', 'list.html'),
                    controller:  'CompanyListController as companies'
                })
                .state('app.company', {
                    url:         '/company/{id}',
                    params:      {id: {value: null}},
                    templateUrl: modulesPath('companies', 'view.html'),
                    controller:  'CompanyViewController as company'
                })

                // Calendar
                // -----------------------------------
                .state('app.calendar', {
                    url:         '/calendar',
                    templateUrl: modulesPath('calendar', 'index.html'),
                    controller:  'CalendarController as calendar'
                })

                // Profiles management
                // -----------------------------------
                .state('app.search', {
                    url:         '/search/?query&filters',
                    params:      {query: {value: null}, filters: {value: null}},
                    templateUrl: modulesPath('profiles', 'search.html'),
                    controller:  'ProfileSearchController as search'
                })

                .state('app.profiles', {
                    url:         '/profiles',
                    templateUrl: modulesPath('profiles', 'list.html')
                })
                .state('app.profile', {
                    url:         '/profile/{id}',
                    params:      {id: {value: null}},
                    templateUrl: modulesPath('profiles', 'view.html'),
                    controller:  'ProfileViewCtrl',
                    resolve:     resolveFor('ngFileUpload')
                })
                .state('app.profile-history', {
                    url:         '/profile-history/{id}',
                    params:      {id: {value: null}},
                    templateUrl: modulesPath('profiles', 'history.html'),
                    controller:  'ProfileHistoryController as history'
                })
                .state('app.profile-parser', {
                    url:         '/profile-parser',
                    templateUrl: modulesPath('profiles', 'parser.html'),
                    controller:  'ProfileParserController as parser',
                    resolve:     resolveFor('ngFileUpload')
                })

                // Projects management
                // -----------------------------------
                .state('app.projects', {
                    url:         '/projects',
                    templateUrl: modulesPath('projects', 'list.html')
                })
                .state('app.project', {
                    url:         '/project/{id}',
                    templateUrl: modulesPath('projects', 'view.html'),
                    controller:  'ProjectViewController as project',
                    abstract:    true
                })
                .state('app.project.board', {
                    url:         '/board',
                    templateUrl: modulesPath('projects', 'view/board.html'),
                    controller:  'ProjectBoardViewController as board'
                })
                .state('app.project.list', {
                    url:         '/list',
                    templateUrl: modulesPath('projects', 'view/list.html'),
                    controller:  'ProjectListViewController as list'
                })
                .state('app.project.archive', {
                    url:         '/archive',
                    templateUrl: modulesPath('projects', 'view/archive.html'),
                    controller:  'ProjectArchiveViewController as archive'
                })
                .state('app.project.history', {
                    url:         '/history',
                    templateUrl: modulesPath('projects', 'view/history.html'),
                    controller:  'ProjectHistoryViewController as history'
                })
                .state('app.project.stat', {
                    url:         '/stat',
                    templateUrl: modulesPath('projects', 'view/stat.html'),
                    controller:  'ProjectStatViewController as stat'
                })

                // Statistics
                // -----------------------------------
                .state('app.stats', {
                    url:         '/stats',
                    templateUrl: modulesPath('stats', 'index.html'),
                    title:       'Статистика',
                    abstract:    true
                })
                .state('app.stats.profiles', {
                    url:         '/profiles',
                    templateUrl: modulesPath('stats', 'profiles.html'),
                    controller:  ['$scope', '$rootScope', function ($scope, $rootScope) {
                        $scope.$on('$stateChangeSuccess', function (event, toState) {
                            // Dat crap
                            if (toState.name === 'app.stats.profiles') {
                                $rootScope.$state.go('.general');
                            }
                        });
                    }],
                    title:       'Статистика кандидатов'
                })
                .state('app.stats.profiles.general', {
                    url:         '/general',
                    templateUrl: modulesPath('stats', 'profiles/general.html'),
                    controller:  'ProfileStatsController as profileStats',
                    title:       'Статистика кандидатов: основные показатели'
                })
                .state('app.stats.profiles.states', {
                    url:         '/states',
                    templateUrl: modulesPath('stats', 'profiles/states.html'),
                    controller:  'ProfileStatesStatsController as profileStats',
                    title:       'Статистика кандидатов: статус в проекте'
                })

                // User settings & notifications
                // -----------------------------------
                .state('app.notifications', {
                    url:         '/notifications',
                    templateUrl: basePath('notifications.html'),
                    controller:  'NotificationListController as notifications'
                })
                .state('app.settings', {
                    url:         '/settings',
                    templateUrl: modulesPath('settings', 'index.html'),
                    controller:  'SettingsController as account'
                })
                .state('app.settings.default', {
                    url:         '/default',
                    templateUrl: modulesPath('settings', 'integrations/index.html')
                })
                .state('app.settings.web', {
                    url:         '/web',
                    templateUrl: modulesPath('settings', 'integrations/web.html')
                })

                // News management
                // -----------------------------------
                .state('app.news', {
                    url:         '/news',
                    templateUrl: modulesPath('news', 'list.html'),
                    controller:  'NewsListController as news'
                })

                // Single Page Routes
                // -----------------------------------
                .state('page', {
                    url:         '/page',
                    abstract:    true,
                    templateUrl: basePath('pages/page.html'),
                    resolve:     resolveFor('modernizr')
                })
                .state('page.login', {
                    url:         '/login',
                    title:       'Вход',
                    templateUrl: basePath('pages/login.html')
                })
                .state('page.registration', {
                    url:         '/registration?source',
                    title:       'Регистрация',
                    templateUrl: basePath('pages/registration.html'),
                    resolve:     resolveFor('ui.mask')
                })
                .state('page.activation', {
                    url:         '/activation/?user&code',
                    title:       'Активация',
                    templateUrl: basePath('pages/activation.html')
                })
                .state('page.404', {
                    url:         '/404',
                    title:       'Страница не найдена',
                    templateUrl: basePath('pages/404.html')
                })
                .state('page.403', {
                    url:         '/403',
                    title:       'Доступ запрещен',
                    templateUrl: basePath('pages/403.html')
                });
        }]);
});