define(['app'], function (app) {
    'use strict';

    app.constant('SETTINGS', {
        info:           {
            name:          'Humile',
            description:   'Подбор персонала - это просто!',
            year:          ((new Date()).getFullYear()),
            isCollapsed:   false,
            isFixed:       true,
            viewAnimation: 'ng-fadeInUp'
        },
        application:    {
            domain:  'app',
            version: 0.32
        },
        defaultImage:   '/assets/img/dummy.png',
        cacheFactories: [
            '$http',
            '$users',
            '$profiles',
            '$projects',
            '$suggests',
            '$companies',
            '$news',
            '$vacancies',
            '$stats'
        ]
    });

    app.constant('MEDIAQUERY', {
        'desktopLG': 1200,
        'desktop':   992,
        'tablet':    768,
        'mobile':    480
    });

    app.constant('MODULES', {
        scripts: {
            'whirl':        ['vendor/whirl/dist/whirl.css'],
            'classyloader': ['vendor/jquery-classyloader/js/jquery.classyloader.min.js'],
            'animo':        ['vendor/animo.js/animo.js'],
            'fastclick':    ['vendor/fastclick/lib/fastclick.js'],
            'modernizr':    ['vendor/modernizr/modernizr.js'],
            'sparklines':   ['scripts/vendor/sparklines/jquery.sparkline.min.js'],
            'slider':       ['vendor/seiyria-bootstrap-slider/dist/bootstrap-slider.min.js',
                'vendor/seiyria-bootstrap-slider/dist/css/bootstrap-slider.min.css'],
            'wysiwyg':      ['vendor/bootstrap-wysiwyg/bootstrap-wysiwyg.js',
                'vendor/bootstrap-wysiwyg/external/jquery.hotkeys.js'],
            'slimscroll':   ['vendor/slimScroll/jquery.slimscroll.min.js'],
            'screenfull':   ['vendor/screenfull/dist/screenfull.min.js'],
            'jquery-ui':    ['vendor/jquery-ui/jquery-ui.min.js',
                'vendor/jqueryui-touch-punch/jquery.ui.touch-punch.min.js'],
            'moment':       ['vendor/moment/min/moment-with-locales.min.js']
        },

        modules: [
            {
                name:  'toaster',
                files: [
                    'vendor/angularjs-toaster/toaster.js',
                    'vendor/angularjs-toaster/toaster.css'
                ]
            },
            {
                name:  'ui.select',
                files: [
                    'vendor/ui-select/dist/select.min.js',
                    'vendor/ui-select/dist/select.min.css'
                ]
            },
            {
                name:  'ui.mask',
                files: [
                    'vendor/angular-ui-mask/dist/mask.min.js'
                ]
            },
            {
                name:  'ngDialog',
                files: [
                    'vendor/ngDialog/js/ngDialog.min.js',
                    'vendor/ngDialog/css/ngDialog.min.css',
                    'vendor/ngDialog/css/ngDialog-theme-default.min.css'
                ]
            },
            {name: 'ngWig', files: ['vendor/ngWig/dist/ng-wig.min.js']},
            {name: 'ngFileUpload', files: ['vendor/ng-file-upload/ng-file-upload-all.min.js']}
        ]

    });
});