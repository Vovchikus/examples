HUMILE | FRONTEND
===================================

Используйте grunt-connect для тестирования и разработки.

Установить node/npm/bower/grunt (npm install -g grunt-cli).

Установить зависимости приложения:

    bower update

Установить зависимости grunt:

    npm install

Запустить локальный сервер с livereload

    grunt live

Собрать билд (НЕ требуется делать локально после изменений)

    grunt build
    
Запустить собранный билд локально (НЕ требуется делать локально после изменений)

    grunt server