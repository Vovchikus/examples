HUMILE FRONTEND | DEPLOY
===================================

Добавить ключ для авторизации на сервер:

    cat ~/.ssh/id_rsa.pub | ssh root@<host> "cat - >> ~/.ssh/authorized_keys2"

Обновление сервера и приложения (если менялась конфигурация):

    ansible-playbook server.yml -i inventory/prod --user root

Обновление только кода приложения:

    ansible-playbook app.yml -i inventory/prod --user root
