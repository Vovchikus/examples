'use strict';

module.exports = function (grunt) {

    // Load grunt tasks automatically
    require('load-grunt-tasks')(grunt);

    // Configurable paths for the app
    var appConfig = {
        app:   'app',
        build: 'build'
    };

    // Grunt configuration
    grunt.initConfig({

        // Project settings
        humile: appConfig,

        // The grunt server settings
        connect: {
            options:    {
                port:       1717,
                hostname:   'localhost',
                livereload: 35729
            },
            livereload: {
                options: {
                    open:       true,
                    middleware: function (connect) {
                        return [
                            connect.static('.tmp'),
                            connect.static(appConfig.app)
                        ];
                    }
                }
            },
            dist:       {
                options: {
                    port: 1777,
                    open: true,
                    base: '<%= humile.build %>'
                }
            }
        },

        // Compile less to css
        less: {
            development: {
                options: {
                    compress:     true,
                    optimization: 2
                },
                files:   {
                    "app/assets/css/style.css":     "app/less/app.less",
                    "app/assets/css/bootstrap.css": "app/less/bootstrap.less"
                }
            }
        },

        requirejs: {
            dist: {
                options: {
                    baseUrl        : '<%= humile.app %>/scripts/',
                    name           : 'bootstrap',
                    mainConfigFile : '<%= humile.app %>/scripts/main.js',
                    out            : '<%= humile.build %>/assets/js/app.min.js',
                    deps:           ['../vendor/requirejs/require', 'main.js'],
                    paths: {
                        calendar: "empty:"
                    }
                }
            }
        },

        // Watch for changes in live edit
        watch: {
            styles:     {
                files:   ['app/less/**/*.less'],
                tasks:   ['less', 'copy:styles'],
                options: {
                    nospawn:    true,
                    livereload: '<%= connect.options.livereload %>'
                }
            },
            js:         {
                files:   ['<%= humile.app %>/scripts/{,*/}*.js'],
                options: {
                    livereload: '<%= connect.options.livereload %>'
                }
            },
            livereload: {
                options: {
                    livereload: '<%= connect.options.livereload %>'
                },
                files:   [
                    '<%= humile.app %>/**/*.html',
                    '.tmp/assets/css/{,*/}*.css',
                    '<%= humile.app %>/assets/img/{,*/}*.{png,jpg,jpeg,gif,webp,svg}'
                ]
            }
        },

        uglify: {
            options: {
                mangle: false
            },
            build:   {
                files: [
                    {
                        expand: true,
                        cwd:    '<%= humile.build %>/scripts',
                        src:    '**/*.js',
                        dest:   '<%= humile.build %>/scripts'
                    }
                ]
            }
        },

        // Clean dist folder
        clean: {
            dist:   {
                files: [{
                    dot: true,
                    src: [
                        '.tmp',
                        '<%= humile.build %>/{,*/}*',
                        '!<%= humile.build %>/.git*'
                    ]
                }]
            },
            server: '.tmp'
        },

        // Copies remaining files to places other tasks can use
        copy: {
            dist:   {
                files: [
                    {
                        expand: true,
                        dot:    true,
                        cwd:    '<%= humile.app %>/vendor/',
                        src:    ['./**/*.js', './**/*.css'],
                        dest:   '<%= humile.build %>/vendor'
                    },
                    {
                        expand: true,
                        dot:    true,
                        cwd:    '<%= humile.app %>/scripts/vendor/',
                        src:    ['./**/*.js', './**/*.css'],
                        dest:   '<%= humile.build %>/scripts/vendor'
                    },
                    {
                        expand: true,
                        dot:    true,
                        cwd:    '<%= humile.app %>',
                        dest:   '<%= humile.build %>',
                        src:    [
                            '*.{ico,png,txt}',
                            '*.html',
                            'scripts/**/{,*/}*.html',
                            'assets/img/**/*.*',
                            'assets/fonts/**/*.*'
                        ]
                    }
                ]
            },
            styles: {
                expand: true,
                cwd:    '<%= humile.app %>/assets/css',
                dest:   '.tmp/assets/css',
                src:    '{,*/}*.css'
            }
        },

        cssmin: {
            options: {
                shorthandCompacting: false,
                roundingPrecision:   -1
            },
            target:  {
                files: {
                    '<%= humile.build %>/assets/css/app.min.css': ['.tmp/assets/css/*.css']
                }
            }
        },

        // Renames files for browser caching purposes
        filerev: {
            options: {
                encoding:  'utf8',
                algorithm: 'md5',
                length:    6
            },
            source:  {
                files: [{
                    src: [
                        '<%= humile.build %>/assets/js/{,*/}*.js',
                        '<%= humile.build %>/assets/css/{,*/}*.css'
                    ]
                }]
            }
        },

        htmlmin: {
            dist: {
                options: {
                    collapseWhitespace:        true,
                    conservativeCollapse:      true,
                    collapseBooleanAttributes: true,
                    removeCommentsFromCDATA:   true,
                    removeOptionalTags:        true
                },
                files:   [{
                    expand: true,
                    cwd:    '<%= humile.build %>',
                    src:    ['*.html', './**/{,*/}*.html'],
                    dest:   '<%= humile.build %>'
                }]
            }
        },

        useminPrepare: {
            html:    '<%= humile.app %>/index.html',
            options: {
                dest: '<%= humile.build %>',
                root: '<%= humile.build %>'
            }
        },

        usemin: {
            html:    ['<%= humile.build %>/index.html'],
            options: {
                assetsDirs: ['<%= humile.build %>', '<%= humile.build %>/assets/css/', '<%= humile.build %>/assets/js/']
            }
        }
    });

    grunt.registerTask('live', [
        'clean:server',
        'copy:styles',
        'connect:livereload',
        'watch'
    ]);

    grunt.registerTask('server', [
        'connect:dist:keepalive'
    ]);

    grunt.registerTask('build', [
        'clean:dist',
        'useminPrepare',
        'less',
        'copy:styles',
        'copy:dist',
        'requirejs:dist',
        'concat',
        'cssmin',
        'filerev',
        'usemin',
        'htmlmin'
    ]);
};